# Steadfast release rules. Capacitor handles its own required keep rules.
