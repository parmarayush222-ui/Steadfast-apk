package com.steadfast.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.text.TextUtils;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.List;

@CapacitorPlugin(name = "AppBlocker")
public class AppBlockerPlugin extends Plugin {

    public static final String PREFS = "steadfast_blocker_prefs";
    public static final String KEY_ACTIVE = "blocking_active";
    public static final String KEY_PACKAGES = "blocked_packages"; // comma-separated package names

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void isAccessibilityEnabled(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("enabled", isServiceEnabled());
        call.resolve(ret);
    }

    @PluginMethod
    public void openAccessibilitySettings(PluginCall call) {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
        call.resolve();
    }

    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        PackageManager pm = getContext().getPackageManager();
        Intent launcherIntent = new Intent(Intent.ACTION_MAIN, null);
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(launcherIntent, 0);

        JSArray result = new JSArray();
        String ownPackage = getContext().getPackageName();
        for (ResolveInfo info : apps) {
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(ownPackage)) continue;
            JSObject app = new JSObject();
            app.put("packageName", pkg);
            app.put("appName", info.loadLabel(pm).toString());
            result.put(app);
        }
        JSObject ret = new JSObject();
        ret.put("apps", result);
        call.resolve(ret);
    }

    @PluginMethod
    public void setBlockedApps(PluginCall call) {
        JSArray packages = call.getArray("packages");
        if (packages == null) { call.reject("packages array required"); return; }
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < packages.length(); i++) {
                if (i > 0) sb.append(",");
                sb.append(packages.getString(i));
            }
            prefs().edit().putString(KEY_PACKAGES, sb.toString()).apply();
            call.resolve();
        } catch (Exception e) {
            call.reject("Failed to save blocked apps", e);
        }
    }

    @PluginMethod
    public void startBlocking(PluginCall call) {
        prefs().edit().putBoolean(KEY_ACTIVE, true).apply();
        call.resolve();
    }

    @PluginMethod
    public void stopBlocking(PluginCall call) {
        prefs().edit().putBoolean(KEY_ACTIVE, false).apply();
        call.resolve();
    }

    @PluginMethod
    public void getBlockingStatus(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("active", prefs().getBoolean(KEY_ACTIVE, false));
        String pkgs = prefs().getString(KEY_PACKAGES, "");
        JSArray arr = new JSArray();
        if (!TextUtils.isEmpty(pkgs)) {
            for (String p : pkgs.split(",")) arr.put(p);
        }
        ret.put("blockedPackages", arr);
        ret.put("accessibilityEnabled", isServiceEnabled());
        call.resolve(ret);
    }

    private boolean isServiceEnabled() {
        String service = getContext().getPackageName() + "/" + BlockerAccessibilityService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(
                getContext().getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (enabledServices == null) return false;
        for (String s : enabledServices.split(":")) {
            if (s.equalsIgnoreCase(service)) return true;
        }
        return false;
    }
}
