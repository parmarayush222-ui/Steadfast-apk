package com.steadfast.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Watches foreground app changes and, only while a Steadfast blocking session is
 *  active, kicks blocked apps back to Home + relaunches Steadfast. State lives in
 *  SharedPreferences (shared with AppBlockerPlugin) so it persists across Steadfast
 *  being closed and survives independently of the web app's own lifecycle. */
public class BlockerAccessibilityService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkgSeq = event.getPackageName();
        if (pkgSeq == null) return;
        String packageName = pkgSeq.toString();
        if (packageName.equals(getPackageName())) return; // never block ourselves

        SharedPreferences prefs = getSharedPreferences(AppBlockerPlugin.PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(AppBlockerPlugin.KEY_ACTIVE, false)) return;

        String pkgsCsv = prefs.getString(AppBlockerPlugin.KEY_PACKAGES, "");
        if (TextUtils.isEmpty(pkgsCsv)) return;
        Set<String> blocked = new HashSet<>(Arrays.asList(pkgsCsv.split(",")));
        if (!blocked.contains(packageName)) return;

        // Interrupt: go Home, then bring Steadfast back to the foreground.
        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(launch);
        }
    }

    @Override
    public void onInterrupt() { }
}
