# Steadfast Android build

1. Install Node.js and Android Studio.
2. From this folder run:
   npm install
   npx cap sync android
3. Open the `android` folder in Android Studio.
4. Let Gradle sync.
5. Build > Build APK(s).

On the phone, open Settings > Accessibility and enable Steadfast's accessibility service before using App Blocker.

The blocker only acts while Steadfast's native `blocking_active` state is true. Selected package names are stored in Android SharedPreferences.
