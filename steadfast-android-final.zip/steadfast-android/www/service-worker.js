const CACHE_NAME = 'steadfast-cache-v2';
const APP_SHELL = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req)
        .then((networkRes) => {
          if (networkRes && networkRes.status === 200 && req.url.startsWith(self.location.origin)) {
            const clone = networkRes.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          }
          return networkRes;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});

/* =====================================================================
   Study session lock-screen / notification-area controls.
   This is the closest thing the open web platform gives an installed PWA
   to an "always-on display" for a background timer: a persistent
   notification with action buttons that keeps working even if the page
   is frozen or fully discarded by the OS. It reads/writes the same
   IndexedDB store the page uses, since a service worker can't touch the
   page's localStorage directly.
   ===================================================================== */
const IDB_NAME = 'steadfast-idb';
const IDB_STORE = 'kv';
function idbOpen() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => { req.result.createObjectStore(IDB_STORE); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbGet(key) {
  const db = await idbOpen();
  return new Promise((resolve) => {
    const tx = db.transaction(IDB_STORE, 'readonly');
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}
async function idbSet(key, value) {
  const db = await idbOpen();
  return new Promise((resolve) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}
async function idbDelete(key) {
  const db = await idbOpen();
  return new Promise((resolve) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).delete(key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}

self.addEventListener('notificationclick', (event) => {
  const action = event.action; // 'pause' | 'resume' | 'stop' | '' (notification body tapped)
  const data = event.notification.data || {};
  event.notification.close();

  event.waitUntil((async () => {
    const clientsList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });

    if (clientsList.length > 0) {
      // The page is still around (even if backgrounded) — let it handle the action with its
      // own state and re-render, rather than duplicating that logic here.
      const msgType = action === 'pause' ? 'study-pause'
        : action === 'resume' ? 'study-resume'
        : action === 'stop' ? 'study-stop'
        : 'reconcile';
      clientsList.forEach((c) => c.postMessage({ type: msgType, subject: data.subject }));
      if (clientsList[0].focus) clientsList[0].focus();
      return;
    }

    // No page open at all — the app was fully closed/discarded. Apply the action directly
    // against the IndexedDB mirror so it's ready to reconcile into study history next launch.
    const mirror = await idbGet('activeSession');
    const now = Date.now();

    if (action === 'stop') {
      if (mirror) {
        await idbSet('pendingStudyStop', { startTs: mirror.startTs, endTs: now, subject: mirror.subject || data.subject || 'Other' });
        await idbDelete('activeSession');
      }
      const list = await self.registration.getNotifications({ tag: 'steadfast-study' });
      list.forEach((n) => n.close());
    } else if (action === 'pause' && mirror && !mirror.isPaused) {
      mirror.elapsedBeforePause = (mirror.elapsedBeforePause || 0) + (now - mirror.startTs);
      mirror.isPaused = true;
      await idbSet('activeSession', mirror);
      await self.registration.showNotification('Steadfast — Study session', {
        body: `Paused — ${mirror.subject || 'Study'}. Elapsed time is saved.`,
        tag: 'steadfast-study', requireInteraction: true, silent: true,
        actions: [{ action: 'resume', title: 'Resume' }, { action: 'stop', title: 'Stop' }],
        data: mirror,
      });
    } else if (action === 'resume' && mirror && mirror.isPaused) {
      mirror.isPaused = false;
      mirror.startTs = now;
      await idbSet('activeSession', mirror);
      await self.registration.showNotification('Steadfast — Study session', {
        body: `Studying ${mirror.subject || 'Study'} since ${new Date(now).toLocaleTimeString()}.`,
        tag: 'steadfast-study', requireInteraction: true, silent: true,
        actions: [{ action: 'pause', title: 'Pause' }, { action: 'stop', title: 'Stop' }],
        data: mirror,
      });
    } else if (!action) {
      // Notification body tapped, no window open — bring the app to the foreground.
      await self.clients.openWindow('./index.html');
    }
  })());
});
