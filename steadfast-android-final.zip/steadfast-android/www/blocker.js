/* Steadfast Android App Blocker bridge. No-ops gracefully when not running inside
   the Capacitor Android app, so the plain web PWA is completely unaffected. */
const AppBlockerBridge = (function () {
  const native = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AppBlocker) || null;
  const available = !!native;
  async function isAccessibilityEnabled() {
    if (!available) return false;
    return !!(await native.isAccessibilityEnabled()).enabled;
  }
  async function openAccessibilitySettings() {
    if (available) return native.openAccessibilitySettings();
  }
  async function getInstalledApps() {
    if (!available) return [];
    const r = await native.getInstalledApps();
    return (r.apps || []).sort((a, b) => a.appName.localeCompare(b.appName));
  }
  async function setBlockedApps(packages) {
    if (available) return native.setBlockedApps({ packages });
  }
  async function startBlocking() {
    if (available) return native.startBlocking();
  }
  async function stopBlocking() {
    if (available) return native.stopBlocking();
  }
  async function getBlockingStatus() {
    if (!available) return { active: false, blockedPackages: [], accessibilityEnabled: false };
    return native.getBlockingStatus();
  }
  return { available, isAccessibilityEnabled, openAccessibilitySettings, getInstalledApps, setBlockedApps, startBlocking, stopBlocking, getBlockingStatus };
})();
