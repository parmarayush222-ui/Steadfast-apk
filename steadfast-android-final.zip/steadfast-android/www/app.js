/* =====================================================================
   STEADFAST — event-based personal discipline tracker
   Data model v2: event log + derived aggregates, instead of a daily survey.
   ===================================================================== */

const STORE_KEY = 'steadfast_v1'; // kept same key so we can migrate in place
const SCHEMA_VERSION = 2;

const TRIGGERS = ['Bored', 'Stress', 'Lonely', 'Scrolling', 'Night', 'Explicit content', 'Other'];
const INTERVENTIONS = [
  { key: 'walk', label: 'Walk 10 min', em: '🚶' },
  { key: 'workout', label: 'Workout', em: '💪' },
  { key: 'study', label: 'Study 15 min', em: '📚' },
  { key: 'phone_away', label: 'Put phone away', em: '📱' },
  { key: 'shower', label: 'Shower', em: '🚿' },
  { key: 'breathe', label: 'Breathe 2 min', em: '🧘' },
];
const STUDY_SUBJECTS_DEFAULT = ['Anatomy', 'Physiology', 'Biochemistry', 'Other'];
const SESSION_TYPES = ['New topic', 'Revision', 'Questions', 'Practical', 'Other'];
const WORKOUT_TYPES = ['Gym', 'Home', 'Cardio', 'Sports', 'Other'];
const SLEEP_OPTIONS = [
  { label: '<6h', value: 5.5 },
  { label: '6h', value: 6 },
  { label: '7h', value: 7 },
  { label: '8h', value: 8 },
  { label: '9h+', value: 9.5 },
];
const MOODS = [
  { value: 1, em: '😞' }, { value: 2, em: '😕' }, { value: 3, em: '😐' },
  { value: 4, em: '🙂' }, { value: 5, em: '😄' },
];

const DEFAULT_HABITS = [
  { id: 'h_meditation', name: 'Meditation', category: 'Mind', type: 'boolean', frequency: { type: 'daily' } },
  { id: 'h_scroll', name: 'No late-night scrolling', category: 'General', type: 'boolean', frequency: { type: 'daily' } },
  { id: 'h_reading', name: 'Reading', category: 'General', type: 'boolean', frequency: { type: 'daily' } },
];

const DEFAULT_SETTINGS = {
  studyDailyMin: 30,       // minutes
  studyDailyTarget: 240,   // minutes
  studyDailyExcellent: 360,// minutes
  studyWeeklyTarget: 1200, // minutes (20h)
  workoutWeeklyTarget: 4,
  meditationWeeklyTarget: 7,
  waterDailyTarget: 3,     // liters
  stepsDailyTarget: 8000,
  studySubjects: STUDY_SUBJECTS_DEFAULT.slice(),
  triggers: TRIGGERS.slice(),
  interventions: INTERVENTIONS.map(i => i.label),
  scoreWeights: { recovery: 25, study: 25, body: 20, mind: 15, habits: 15 },
  pomodoroWorkMin: 25,
  pomodoroBreakMin: 5,
};

/* ===================== Storage & migration ===================== */
function freshState() {
  return {
    version: SCHEMA_VERSION,
    habits: DEFAULT_HABITS.map(h => ({ ...h })),
    events: [],
    days: {},           // dateKey -> { recoveryOverride: 'REST'|null }
    settings: JSON.parse(JSON.stringify(DEFAULT_SETTINGS)),
    activeSession: null, // { startTs, elapsedBeforePause, isPaused, pauseStartTs, subject, mode, pomodoro }
    theme: 'system', // 'system' | 'light' | 'dark' — existing users keep whatever they already had
    installedAt: Date.now(), // anchors streaks/insights so pre-install days never count as "on track"
  };
}

function migrateFromV1(old) {
  const next = freshState();
  next.theme = old.theme || 'dark';

  // migrate habits (old ones were boolean, keep as boolean habits under General)
  if (Array.isArray(old.habits) && old.habits.length) {
    next.habits = old.habits.map(h => ({
      id: h.id, name: h.name,
      category: h.category === 'Recovery' ? 'General' : (h.category || 'General'),
      type: 'boolean',
      frequency: { type: 'daily' },
    }));
  }

  let counter = 0;
  const nextId = (prefix) => `${prefix}_${Date.now()}_${counter++}`;

  const logs = old.logs || {};
  let earliestTs = null;
  Object.entries(logs).forEach(([dateKey, log]) => {
    const baseTs = new Date(dateKey + 'T12:00:00').getTime();
    if (earliestTs === null || baseTs < earliestTs) earliestTs = baseTs;

    if (log.pornStatus === 'REST') {
      next.days[dateKey] = { recoveryOverride: 'REST' };
    } else if (log.pornStatus === 'SLIPPED') {
      const slipId = nextId('slip');
      next.events.push({
        id: slipId, type: 'slip', ts: baseTs, dateKey,
        trigger: (log.triggers && log.triggers[0]) || null,
      });
    }

    if (log.urge && log.urge > 0) {
      const urgeId = nextId('urge');
      next.events.push({ id: urgeId, type: 'urge', ts: baseTs - 60000, dateKey, intensity: log.urge });
      (log.helpers || []).forEach(helper => {
        next.events.push({
          id: nextId('intervention'), type: 'intervention', ts: baseTs - 30000, dateKey,
          urgeEventId: urgeId, intervention: helper, postIntensity: null,
        });
      });
    }

    Object.entries(log.habitCompletions || {}).forEach(([habitId, done]) => {
      if (!done) return;
      next.events.push({ id: nextId('habit'), type: 'habit', ts: baseTs, dateKey, habitId, value: true });
    });

    if (log.notes) {
      next.events.push({ id: nextId('note'), type: 'note', ts: baseTs, dateKey, text: log.notes });
    }
  });

  // anchor installedAt to the earliest real record instead of "now", so migrated users
  // keep whatever real history they had — but still never earlier than actual data.
  next.installedAt = earliestTs !== null ? earliestTs : Date.now();
  next._migratedFromV1At = Date.now();
  return next;
}

function loadState() {
  let raw;
  try { raw = localStorage.getItem(STORE_KEY); } catch (e) { raw = null; }
  if (!raw) return freshState();
  let parsed;
  try { parsed = JSON.parse(raw); } catch (e) { return freshState(); }

  if (!parsed.version || parsed.version < 2) {
    // preserve the raw legacy blob just in case, then migrate
    try { localStorage.setItem(STORE_KEY + '_legacy_backup', raw); } catch (e) {}
    return migrateFromV1(parsed);
  }

  // ensure shape integrity for anyone on v2 already
  parsed.habits = parsed.habits || [];
  parsed.events = parsed.events || [];
  parsed.days = parsed.days || {};
  parsed.settings = { ...JSON.parse(JSON.stringify(DEFAULT_SETTINGS)), ...(parsed.settings || {}) };
  parsed.theme = parsed.theme || 'dark';
  if (!parsed.installedAt) {
    // pre-existing v2 users who predate this fix — anchor to their earliest real event
    // rather than "now", so real history isn't truncated.
    const earliest = parsed.events.reduce((min, e) => (min === null || e.ts < min ? e.ts : min), null);
    parsed.installedAt = earliest !== null ? earliest : Date.now();
  }
  return parsed;
}

let state = loadState();
let saveTimer = null;
function saveState() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { console.warn('save failed', e); }
  }, 120);
}
function saveStateNow() {
  clearTimeout(saveTimer);
  try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { console.warn('save failed', e); }
}

/* ===================== Date helpers ===================== */
function fmtDate(d) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function todayKey() { return fmtDate(new Date()); }
function parseDateKey(key) { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); }
function addDays(d, n) { const r = new Date(d); r.setDate(r.getDate() + n); return r; }
function dateKeyFromTs(ts) { return fmtDate(new Date(ts)); }
function longDateLabel(d) { return d.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }); }
function shortDateLabel(d) { return d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }); }
function timeLabel(ts) { return new Date(ts).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }
function fmtMinutes(min) {
  min = Math.round(min);
  const h = Math.floor(min / 60), m = min % 60;
  if (h <= 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}
function startOfWeek(d) {
  const r = new Date(d);
  const day = r.getDay(); // 0 = Sunday
  r.setDate(r.getDate() - day);
  r.setHours(0, 0, 0, 0);
  return r;
}
function isSameWeek(d1, d2) { return fmtDate(startOfWeek(d1)) === fmtDate(startOfWeek(d2)); }

/* ===================== Event helpers ===================== */
let evtCounter = 0;
function makeId(prefix) { return `${prefix}_${Date.now()}_${evtCounter++}`; }

function addEvent(evt) {
  const full = { id: makeId(evt.type), ts: Date.now(), ...evt };
  full.dateKey = full.dateKey || dateKeyFromTs(full.ts);
  state.events.push(full);
  saveState();
  return full;
}
function updateEvent(id, patch) {
  const evt = state.events.find(e => e.id === id);
  if (evt) { Object.assign(evt, patch); saveState(); }
  return evt;
}
function eventsForDate(dateKey) { return state.events.filter(e => e.dateKey === dateKey); }
function eventsInRange(startDate, endDate) {
  const startTs = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), 0, 0, 0).getTime();
  const endTs = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 23, 59, 59).getTime();
  return state.events.filter(e => e.ts >= startTs && e.ts <= endTs);
}
function eventsOfType(list, type) { return list.filter(e => e.type === type); }

function dayRecoveryStatus(dateKey) {
  const evts = eventsForDate(dateKey);
  if (evts.some(e => e.type === 'slip')) return 'SLIPPED';
  const override = state.days[dateKey];
  if (override && override.recoveryOverride === 'REST') return 'REST';
  return 'ON_TRACK'; // implicit — no news is good news
}

/* ===================== Day aggregation ===================== */
function computeDayAggregate(dateKey) {
  const evts = eventsForDate(dateKey);
  const studyEvts = eventsOfType(evts, 'study');
  const studyMin = studyEvts.reduce((s, e) => s + (e.durationMin || 0), 0);
  const workoutEvts = eventsOfType(evts, 'workout');
  const meditationEvts = eventsOfType(evts, 'meditation');
  const moodEvts = eventsOfType(evts, 'mood');
  const energyEvts = eventsOfType(evts, 'energy');
  const waterEvts = eventsOfType(evts, 'water');
  const stepsEvts = eventsOfType(evts, 'steps');
  const sleepEvts = eventsOfType(evts, 'sleep');
  const urgeEvts = eventsOfType(evts, 'urge');
  const slipEvts = eventsOfType(evts, 'slip');
  const habitEvts = eventsOfType(evts, 'habit');

  const habitDone = {};
  habitEvts.forEach(e => { habitDone[e.habitId] = e.value; });

  return {
    dateKey,
    recoveryStatus: dayRecoveryStatus(dateKey),
    studyMin,
    studySessions: studyEvts.length,
    workoutDone: workoutEvts.length > 0,
    workoutEvents: workoutEvts,
    meditationDone: meditationEvts.length > 0,
    mood: moodEvts.length ? moodEvts[moodEvts.length - 1].value : null,
    energy: energyEvts.length ? energyEvts[energyEvts.length - 1].value : null,
    water: waterEvts.reduce((s, e) => s + (e.amountL || 0), 0),
    steps: stepsEvts.length ? stepsEvts[stepsEvts.length - 1].count : null,
    sleep: sleepEvts.length ? sleepEvts[sleepEvts.length - 1].hours : null,
    urgeCount: urgeEvts.length,
    avgUrge: urgeEvts.length ? urgeEvts.reduce((s, e) => s + e.intensity, 0) / urgeEvts.length : null,
    slipCount: slipEvts.length,
    habitDone,
  };
}

/* ===================== Study session manager (persisted, survives reload) =====================
   Elapsed time is always derived from stored timestamps, never from a running setInterval
   count — so it stays correct even if the tab is frozen, discarded, or the phone is locked
   while a session is active.

   Two modes:
   - 'freeform': counts all elapsed time (existing behavior, unchanged).
   - 'pomodoro': alternates work/break phases. Only WORK time counts toward study duration;
     break time is tracked but excluded. Phase timing uses the same accumulate-on-pause
     pattern as freeform, just scoped to the current phase. */
function getActiveSessionElapsedMs() {
  const s = state.activeSession;
  if (!s) return 0;
  if (s.isPaused) return s.elapsedBeforePause;
  return s.elapsedBeforePause + (Date.now() - s.startTs);
}
function getCurrentPhaseElapsedMs() {
  const s = state.activeSession;
  if (!s || !s.pomodoro) return 0;
  const p = s.pomodoro;
  return p.phaseAccumMs + (s.isPaused ? 0 : Date.now() - p.phaseStartTs);
}
/* Study time actually counted toward duration — for freeform this is total elapsed;
   for pomodoro this is completed work phases plus any work-in-progress right now. */
function getStudyCountedMs() {
  const s = state.activeSession;
  if (!s) return 0;
  if (!s.pomodoro) return getActiveSessionElapsedMs();
  const p = s.pomodoro;
  return p.workTotalMs + (p.phase === 'work' ? getCurrentPhaseElapsedMs() : 0);
}
function lastStudySubjectGuess() {
  return state.settings.lastStudySubject || (state.settings.studySubjects && state.settings.studySubjects[0]) || 'Study';
}
function startStudySession(mode) {
  if (state.activeSession) return;
  const session = { startTs: Date.now(), elapsedBeforePause: 0, isPaused: false, pauseStartTs: null, subject: null, mode: mode === 'pomodoro' ? 'pomodoro' : 'freeform' };
  if (session.mode === 'pomodoro') {
    session.pomodoro = {
      workMin: state.settings.pomodoroWorkMin,
      breakMin: state.settings.pomodoroBreakMin,
      phase: 'work',
      phaseStartTs: Date.now(),
      phaseAccumMs: 0,
      workTotalMs: 0,
      cyclesCompleted: 0,
    };
  }
  state.activeSession = session;
  saveStateNow();
  syncSessionToIDB();
  ensureNotificationPermission().then(() => notifyStudyState());
}
function pauseStudySession() {
  const s = state.activeSession;
  if (!s || s.isPaused) return;
  if (s.pomodoro) {
    s.pomodoro.phaseAccumMs += Date.now() - s.pomodoro.phaseStartTs;
  } else {
    s.elapsedBeforePause += Date.now() - s.startTs;
  }
  s.isPaused = true;
  saveStateNow();
  syncSessionToIDB();
  notifyStudyState();
}
function resumeStudySession() {
  const s = state.activeSession;
  if (!s || !s.isPaused) return;
  if (s.pomodoro) {
    s.pomodoro.phaseStartTs = Date.now();
  } else {
    s.startTs = Date.now();
  }
  s.isPaused = false;
  saveStateNow();
  syncSessionToIDB();
  notifyStudyState();
}
/* Called every second (see the global interval near init) — advances work/break phases
   automatically once the current phase's target duration is reached. No-ops for freeform
   sessions and while paused. */
function checkPomodoroPhase() {
  const s = state.activeSession;
  if (!s || !s.pomodoro || s.isPaused) return;
  const p = s.pomodoro;
  const targetMs = (p.phase === 'work' ? p.workMin : p.breakMin) * 60000;
  const phaseElapsed = p.phaseAccumMs + (Date.now() - p.phaseStartTs);
  if (phaseElapsed < targetMs) return;
  if (p.phase === 'work') {
    p.workTotalMs += targetMs;
    p.phase = 'break';
  } else {
    p.phase = 'work';
    p.cyclesCompleted++;
  }
  p.phaseStartTs = Date.now();
  p.phaseAccumMs = 0;
  saveStateNow();
  syncSessionToIDB();
  notifyStudyState();
  if (focusModeOpen) renderFocusMode();
  toast(p.phase === 'work' ? '🍅 Back to work!' : '☕ Break time!');
}
function cancelStudySession() {
  state.activeSession = null;
  saveStateNow();
  clearSessionFromIDB();
  clearStudyNotification();
}
function stopStudySession(subject, sessionType) {
  const s = state.activeSession;
  if (!s) return null;
  const elapsedMs = getStudyCountedMs();
  const durationMin = Math.max(1, Math.round(elapsedMs / 60000));
  const endTs = Date.now();
  const startTs = endTs - elapsedMs;
  const finalSubject = subject || 'Other';
  const evt = addEvent({
    type: 'study', ts: endTs, dateKey: dateKeyFromTs(endTs),
    startTs, endTs, durationMin, subject: finalSubject, sessionType: sessionType || null,
    mode: s.mode, pomodoroCycles: s.pomodoro ? s.pomodoro.cyclesCompleted : undefined,
  });
  state.activeSession = null;
  state.settings.lastStudySubject = finalSubject;
  saveStateNow();
  clearSessionFromIDB();
  clearStudyNotification();
  return evt;
}

/* ===================== IndexedDB bridge (page <-> service worker) =====================
   localStorage isn't reachable from a service worker, but the lock-screen notification's
   Pause/Resume/Stop actions run in the service worker even when this page is backgrounded
   or discarded. IndexedDB is the one storage both sides can read/write, so the active
   session (and any action taken from the notification while the page wasn't open) is
   mirrored here and reconciled the next time the app is in the foreground. */
const IDB_NAME = 'steadfast-idb';
const IDB_STORE = 'kv';
function idbOpen() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) { reject(new Error('no indexedDB')); return; }
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => { req.result.createObjectStore(IDB_STORE); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbSet(key, value) {
  try {
    const db = await idbOpen();
    return new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(value, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) { return false; }
}
async function idbGet(key) {
  try {
    const db = await idbOpen();
    return new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch (e) { return null; }
}
async function idbDelete(key) {
  try {
    const db = await idbOpen();
    return new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) { return false; }
}
function syncSessionToIDB() {
  const s = state.activeSession;
  if (!s) { clearSessionFromIDB(); return; }
  idbSet('activeSession', {
    startTs: s.startTs, elapsedBeforePause: s.elapsedBeforePause, isPaused: s.isPaused,
    subject: s.subject || lastStudySubjectGuess(),
  });
}
function clearSessionFromIDB() { idbDelete('activeSession'); }

/* ===================== Lock-screen / notification-area session status =====================
   True always-on-display / live-updating lock-screen control isn't something the open web
   platform exposes to installed PWAs (that requires native code). The closest supported
   mechanism is a persistent Service Worker notification with action buttons, which keeps
   working even if this page is frozen or discarded — that's what this implements. */
async function ensureNotificationPermission() {
  if (!('Notification' in window) || !('serviceWorker' in navigator)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  try { return (await Notification.requestPermission()) === 'granted'; } catch (e) { return false; }
}
async function notifyStudyState() {
  if (!('serviceWorker' in navigator) || !('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;
  const s = state.activeSession;
  if (!s) { clearStudyNotification(); return; }
  try {
    const reg = await navigator.serviceWorker.ready;
    const subject = s.subject || lastStudySubjectGuess();
    const body = s.isPaused
      ? `Paused — ${subject}. Elapsed time is saved; reopen Steadfast to see it.`
      : `Studying ${subject} since ${timeLabel(s.startTs)}.`;
    reg.showNotification('Steadfast — Study session', {
      body, tag: 'steadfast-study', requireInteraction: true, silent: true,
      actions: s.isPaused
        ? [{ action: 'resume', title: 'Resume' }, { action: 'stop', title: 'Stop' }]
        : [{ action: 'pause', title: 'Pause' }, { action: 'stop', title: 'Stop' }],
      data: { startTs: s.startTs, elapsedBeforePause: s.elapsedBeforePause, isPaused: s.isPaused, subject },
    });
  } catch (e) { /* notifications unsupported/blocked — timer still works via timestamps */ }
}
async function clearStudyNotification() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.ready;
    const list = await reg.getNotifications({ tag: 'steadfast-study' });
    list.forEach(n => n.close());
  } catch (e) {}
}
/* Reconcile after the app was backgrounded/closed: pick up any Stop/Pause/Resume action taken
   from the notification while this page wasn't running, using the IndexedDB mirror as the
   source of truth for timestamps. */
async function reconcileStudySessionFromBackground() {
  try {
    const pendingStop = await idbGet('pendingStudyStop');
    if (pendingStop) {
      const durationMin = Math.max(1, Math.round((pendingStop.endTs - pendingStop.startTs) / 60000));
      addEvent({
        type: 'study', ts: pendingStop.endTs, dateKey: dateKeyFromTs(pendingStop.endTs),
        startTs: pendingStop.startTs, endTs: pendingStop.endTs, durationMin,
        subject: pendingStop.subject || 'Other', sessionType: null,
      });
      state.activeSession = null;
      state.settings.lastStudySubject = pendingStop.subject || state.settings.lastStudySubject;
      saveStateNow();
      await idbDelete('pendingStudyStop');
      await idbDelete('activeSession');
      renderToday();
      toast(`Logged ${fmtMinutes(durationMin)} of ${pendingStop.subject || 'Other'} (stopped from notification)`);
      return;
    }
    const mirror = await idbGet('activeSession');
    if (mirror && state.activeSession) {
      if (mirror.isPaused !== state.activeSession.isPaused || mirror.startTs !== state.activeSession.startTs) {
        state.activeSession.isPaused = mirror.isPaused;
        state.activeSession.startTs = mirror.startTs;
        state.activeSession.elapsedBeforePause = mirror.elapsedBeforePause;
        saveStateNow();
        renderToday();
      }
    } else if (!mirror && state.activeSession) {
      // session was stopped/cleared via the notification with no page open to catch pendingStudyStop
      // (shouldn't normally happen since the SW always writes pendingStudyStop on Stop, but guard anyway)
    }
  } catch (e) { /* best effort */ }
}

/* ===================== Streaks (recovery) ===================== */
/* installedDateKey anchors every backward-looking calculation so a day before the app
   was ever used can't silently count as "on track" — that was the root cause of a fresh
   install showing an inflated multi-year streak. */
function installedDateKey() { return fmtDate(new Date(state.installedAt || Date.now())); }

function computeCurrentStreak() {
  let count = 0;
  let cursor = new Date();
  const instKey = installedDateKey();
  while (true) {
    const key = fmtDate(cursor);
    if (key < instKey) break; // don't count days before the app was ever used
    const status = dayRecoveryStatus(key);
    if (status === 'SLIPPED') break;
    if (status === 'ON_TRACK') count++;
    // REST is neutral — continue without incrementing
    cursor = addDays(cursor, -1);
    if (count > 3650) break; // hard safety cap only, shouldn't normally be reachable now
  }
  return count;
}
function computeBestStreak() {
  const allDateKeys = new Set();
  state.events.forEach(e => allDateKeys.add(e.dateKey));
  Object.keys(state.days).forEach(k => allDateKeys.add(k));
  allDateKeys.add(todayKey());
  allDateKeys.add(installedDateKey());
  if (!allDateKeys.size) return 0;
  const keys = Array.from(allDateKeys).filter(k => k >= installedDateKey()).sort();
  const start = parseDateKey(keys[0]);
  const end = new Date();
  let best = 0, running = 0;
  for (let d = new Date(start); d <= end; d = addDays(d, 1)) {
    const status = dayRecoveryStatus(fmtDate(d));
    if (status === 'SLIPPED') { running = 0; }
    else if (status === 'ON_TRACK') { running++; best = Math.max(best, running); }
    // REST neutral
  }
  return best;
}
function cleanDaysInRange(startDate, endDate) {
  const instKey = installedDateKey();
  let count = 0;
  for (let d = new Date(startDate); d <= endDate; d = addDays(d, 1)) {
    const key = fmtDate(d);
    if (key < instKey) continue; // not trackable — the app wasn't installed yet
    if (dayRecoveryStatus(key) !== 'SLIPPED') count++;
  }
  return count;
}

/* ===================== Discipline score ===================== */
function computeDisciplineScore(dateKey) {
  const agg = computeDayAggregate(dateKey);
  const w = state.settings.scoreWeights;

  // Recovery: full marks unless slipped (slip doesn't zero the whole day, just this component)
  const recoveryScore = agg.recoveryStatus === 'SLIPPED' ? 0.3 : 1;

  // Study: scaled against target, capped at 1, small credit even below minimum
  const target = state.settings.studyDailyTarget || 1;
  const studyScore = Math.min(1, agg.studyMin / target);

  // Body: workout done + sleep logged reasonably + water progress, averaged
  let bodyParts = [];
  bodyParts.push(agg.workoutDone ? 1 : 0);
  if (agg.sleep != null) bodyParts.push(Math.min(1, agg.sleep / 8));
  if (state.settings.waterDailyTarget) bodyParts.push(Math.min(1, agg.water / state.settings.waterDailyTarget));
  const bodyScore = bodyParts.length ? bodyParts.reduce((a, b) => a + b, 0) / bodyParts.length : (agg.workoutDone ? 1 : 0);

  // Mind: meditation + mood presence
  let mindParts = [];
  mindParts.push(agg.meditationDone ? 1 : 0);
  if (agg.mood != null) mindParts.push(agg.mood / 5);
  const mindScore = mindParts.length ? mindParts.reduce((a, b) => a + b, 0) / mindParts.length : (agg.meditationDone ? 1 : 0);

  // Habits: fraction of scheduled-for-today habits completed
  const scheduled = habitsScheduledOn(dateKey);
  const habitsScore = scheduled.length
    ? scheduled.filter(h => agg.habitDone[h.id]).length / scheduled.length
    : 1;

  const total =
    recoveryScore * w.recovery +
    studyScore * w.study +
    bodyScore * w.body +
    mindScore * w.mind +
    habitsScore * w.habits;

  return Math.round(total);
}

function habitsScheduledOn(dateKey) {
  const d = parseDateKey(dateKey);
  const weekday = d.getDay();
  return state.habits.filter(h => {
    const f = h.frequency || { type: 'daily' };
    if (f.type === 'daily') return true;
    if (f.type === 'week_days') return (f.days || []).includes(weekday);
    if (f.type === 'times_per_week') return true; // shown daily, judged weekly in insights
    return true;
  });
}

/* ===================== Navigation ===================== */
const views = ['today', 'calendar', 'insights', 'habits', 'settings'];
function switchView(name) {
  views.forEach(v => document.getElementById(`view-${v}`).classList.toggle('hidden', v !== name));
  document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.target === name));
  if (name === 'today') renderToday();
  if (name === 'calendar') renderCalendar();
  if (name === 'insights') renderInsights();
  if (name === 'habits') renderHabitsScreen();
  if (name === 'settings') renderSettings();
}
document.getElementById('bottom-nav').addEventListener('click', (e) => {
  const btn = e.target.closest('.nav-item');
  if (btn) switchView(btn.dataset.target);
});

/* ===================== Generic modal / bottom sheet ===================== */
const modalOverlay = document.getElementById('modal-overlay');
const modalBody = document.getElementById('modal-body');
function openModal(html, onMount) {
  modalBody.innerHTML = html;
  modalOverlay.classList.remove('hidden');
  if (onMount) onMount(modalBody);
}
function closeModal() {
  modalOverlay.classList.add('hidden');
  modalBody.innerHTML = '';
  stopModalTimerLoop();
}
modalOverlay.addEventListener('click', (e) => { if (e.target === modalOverlay) closeModal(); });

/* ===================== Utility ===================== */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}
function toast(msg) {
  const t = document.createElement('div');
  t.className = 'install-toast';
  t.style.bottom = 'calc(var(--nav-h) + 12px)';
  t.innerHTML = `<span>${escapeHtml(msg)}</span>`;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 1800);
}

/* ===================== QUICK ADD FAB ===================== */
document.getElementById('quick-add-fab').addEventListener('click', openQuickAddMenu);

function openQuickAddMenu() {
  openModal(`
    <h2 class="modal-title">Quick log</h2>
    <p class="modal-subtitle">Log it and get back to your day.</p>
    <div class="quick-grid" id="qa-grid">
      <button class="quick-opt" data-action="study"><span class="em">📚</span> Study session</button>
      <button class="quick-opt" data-action="urge"><span class="em">🔥</span> Urge</button>
      <button class="quick-opt" data-action="slip"><span class="em">🚨</span> Slip</button>
      <button class="quick-opt" data-action="workout"><span class="em">💪</span> Workout</button>
      <button class="quick-opt" data-action="meditation"><span class="em">🧘</span> Meditation</button>
      <button class="quick-opt" data-action="mood"><span class="em">🙂</span> Mood</button>
      <button class="quick-opt" data-action="water"><span class="em">💧</span> Water</button>
      <button class="quick-opt" data-action="habit"><span class="em">✓</span> Habit</button>
      <button class="quick-opt" data-action="note"><span class="em">📝</span> Note</button>
    </div>
  `, (root) => {
    root.querySelector('#qa-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt');
      if (!btn) return;
      const action = btn.dataset.action;
      const handlers = {
        study: openStudyFlow, urge: openUrgeFlow, slip: openSlipFlow, workout: openWorkoutFlow,
        meditation: openMeditationFlow, mood: openMoodFlow, water: openWaterFlow,
        habit: openHabitQuickFlow, note: openNoteFlow,
      };
      handlers[action] && handlers[action]();
    });
  });
}

/* ===================== Modal timer loop (for the study stopwatch) ===================== */
let modalTimerInterval = null;
function stopModalTimerLoop() { if (modalTimerInterval) { clearInterval(modalTimerInterval); modalTimerInterval = null; } }

/* ===================== STUDY flow ===================== */
function openStudyFlow() {
  if (state.activeSession) { openFocusMode(); return; }
  openModal(`
    <h2 class="modal-title">📚 Start studying</h2>
    <p class="modal-subtitle">Opens full-screen Focus Mode right away.</p>
    <button class="modal-btn" id="start-freeform-btn">▶ Freeform timer</button>
    <button class="modal-btn secondary" id="start-pomodoro-btn">🍅 Pomodoro (${state.settings.pomodoroWorkMin}/${state.settings.pomodoroBreakMin} min)</button>
    <button class="modal-btn ghost" id="cancel-study-btn">Cancel</button>
  `, (root) => {
    root.querySelector('#start-freeform-btn').addEventListener('click', () => {
      closeModal(); startStudySession('freeform'); openFocusMode();
    });
    root.querySelector('#start-pomodoro-btn').addEventListener('click', () => {
      closeModal(); startStudySession('pomodoro'); openFocusMode();
    });
    root.querySelector('#cancel-study-btn').addEventListener('click', closeModal);
  });
}

/* ===================== FOCUS MODE =====================
   This is now the primary study UI — opened immediately on Start, and again any time the
   Study card is tapped while a session is already running. It also carries Pomodoro phase
   display and today's running study progress, since the app leans into study/academics
   as one of its two core pillars alongside recovery. */
let focusModeOpen = false;
let focusModeEl = null;
function openFocusMode() {
  if (!state.activeSession) { startStudySession('freeform'); renderToday(); }
  ensureNotificationPermission().then(() => notifyStudyState());
  focusModeOpen = true;
  if (!focusModeEl) {
    focusModeEl = document.createElement('div');
    focusModeEl.id = 'focus-mode';
    focusModeEl.className = 'focus-mode';
    document.body.appendChild(focusModeEl);
  }
  renderFocusMode();
  focusModeEl.classList.add('visible');
  requestWakeLock();
}
function closeFocusMode() {
  focusModeOpen = false;
  if (focusModeEl) focusModeEl.classList.remove('visible');
  releaseWakeLock();
  renderToday();
}
function renderFocusMode() {
  const s = state.activeSession;
  if (!s) { closeFocusMode(); return; }
  const subject = s.subject || lastStudySubjectGuess();
  const isPomodoro = !!s.pomodoro;
  const todayAgg = computeDayAggregate(todayKey());
  const todayProgressPct = Math.min(100, Math.round((todayAgg.studyMin / state.settings.studyDailyTarget) * 100));

  let phaseLabelHtml = '';
  if (isPomodoro) {
    const p = s.pomodoro;
    const dots = Array.from({ length: Math.max(p.cyclesCompleted, 1) }, (_, i) =>
      `<span style="opacity:${i < p.cyclesCompleted ? '1' : '0.25'};">🍅</span>`
    ).join(' ');
    phaseLabelHtml = `<div class="focus-phase-badge ${p.phase}">${p.phase === 'work' ? '🍅 Work' : '☕ Break'}</div><div class="focus-cycles">${dots}</div>`;
  }

  focusModeEl.innerHTML = `
    <div class="focus-topbar">
      <button class="focus-minimize" id="focus-minimize-btn" aria-label="Minimize focus mode">⌄</button>
      <span class="focus-title">Focus Mode</span>
      <button class="focus-stop-btn" id="focus-stop-btn">Stop</button>
    </div>
    <div class="focus-body">
      <button class="focus-subject-pill" id="focus-subject-btn">${escapeHtml(subject)} <span class="chevron">▾</span></button>
      ${phaseLabelHtml}
      <div class="focus-timer" id="focus-timer-display">00:00:00</div>
      <div class="focus-status">${s.isPaused ? 'Paused' : (isPomodoro ? (s.pomodoro.phase === 'work' ? "Stay focused. You've got this! 🔥" : 'Step away — back to it soon.') : "Stay focused. You've got this! 🔥")}</div>
      <div class="focus-controls">
        <button class="focus-pause-circle" id="focus-pause-btn" aria-label="${s.isPaused ? 'Resume' : 'Pause'}">${s.isPaused ? '▶' : '⏸'}</button>
        <button class="focus-reset-circle" id="focus-reset-btn" aria-label="Discard session">↻</button>
      </div>
      <div class="focus-footer">Today: ${fmtMinutes(todayAgg.studyMin)} / ${fmtMinutes(state.settings.studyDailyTarget)}
        <span class="focus-footer-track"><span class="focus-footer-fill" style="width:${todayProgressPct}%"></span></span>
      </div>
    </div>
  `;
  updateFocusDisplay();
  focusModeEl.querySelector('#focus-minimize-btn').addEventListener('click', closeFocusMode);
  focusModeEl.querySelector('#focus-subject-btn').addEventListener('click', openFocusSubjectPicker);
  focusModeEl.querySelector('#focus-pause-btn').addEventListener('click', () => {
    if (state.activeSession.isPaused) resumeStudySession(); else pauseStudySession();
    renderFocusMode();
  });
  focusModeEl.querySelector('#focus-stop-btn').addEventListener('click', () => {
    closeFocusMode();
    if (state.activeSession && state.activeSession.subject) {
      // subject already chosen during the session — skip straight to the (still optional) session-type step
      openSessionTypePicker(state.activeSession.subject);
    } else {
      openSubjectPicker();
    }
  });
  focusModeEl.querySelector('#focus-reset-btn').addEventListener('click', () => {
    if (confirm('Discard this study session? Time will not be saved.')) {
      cancelStudySession(); closeFocusMode();
    }
  });
}
function openFocusSubjectPicker() {
  const subjects = state.settings.studySubjects;
  openModal(`
    <h2 class="modal-title">Studying...</h2>
    <p class="modal-subtitle">This just labels the session — you can still change it when you stop.</p>
    <div class="quick-grid" id="focus-subject-grid">
      ${subjects.map(s => `<button class="quick-opt" data-subject="${escapeHtml(s)}">${escapeHtml(s)}</button>`).join('')}
    </div>
  `, (root) => {
    root.querySelector('#focus-subject-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      state.activeSession.subject = btn.dataset.subject;
      saveStateNow();
      syncSessionToIDB();
      notifyStudyState();
      closeModal();
      renderFocusMode();
    });
  });
}
function updateFocusDisplay() {
  if (!focusModeOpen || !focusModeEl || !state.activeSession) return;
  const el = focusModeEl.querySelector('#focus-timer-display');
  if (!el) return;
  const s = state.activeSession;
  let totalSec;
  if (s.pomodoro) {
    const p = s.pomodoro;
    const targetMs = (p.phase === 'work' ? p.workMin : p.breakMin) * 60000;
    totalSec = Math.max(0, Math.floor((targetMs - getCurrentPhaseElapsedMs()) / 1000)); // countdown to phase end
  } else {
    totalSec = Math.floor(getActiveSessionElapsedMs() / 1000); // count up
  }
  const h = Math.floor(totalSec / 3600), m = Math.floor((totalSec % 3600) / 60), sec = totalSec % 60;
  el.textContent = h > 0
    ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
    : `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

/* ===================== Wake Lock (screen-on only while Focus Mode is actually open) ===================== */
let wakeLockSentinel = null;
async function requestWakeLock() {
  if (!('wakeLock' in navigator) || document.visibilityState !== 'visible') return;
  try { wakeLockSentinel = await navigator.wakeLock.request('screen'); } catch (e) { wakeLockSentinel = null; }
}
function releaseWakeLock() {
  if (wakeLockSentinel) { wakeLockSentinel.release().catch(() => {}); wakeLockSentinel = null; }
}
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && focusModeOpen) requestWakeLock();
  else releaseWakeLock();
});
function openSubjectPicker() {
  stopModalTimerLoop();
  const subjects = state.settings.studySubjects;
  openModal(`
    <h2 class="modal-title">What did you study?</h2>
    <div class="quick-grid" id="subject-grid">
      ${subjects.map(s => `<button class="quick-opt" data-subject="${escapeHtml(s)}">${escapeHtml(s)}</button>`).join('')}
    </div>
  `, (root) => {
    root.querySelector('#subject-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      openSessionTypePicker(btn.dataset.subject);
    });
  });
}
function openSessionTypePicker(subject) {
  openModal(`
    <h2 class="modal-title">Session type</h2>
    <p class="modal-subtitle">Optional.</p>
    <div class="quick-grid" id="type-grid">
      ${SESSION_TYPES.map(t => `<button class="quick-opt" data-type="${escapeHtml(t)}">${escapeHtml(t)}</button>`).join('')}
    </div>
    <button class="modal-btn secondary" id="skip-type-btn">Skip</button>
  `, (root) => {
    root.querySelector('#type-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      finishStudy(subject, btn.dataset.type);
    });
    root.querySelector('#skip-type-btn').addEventListener('click', () => finishStudy(subject, null));
  });
}
function finishStudy(subject, sessionType) {
  const evt = stopStudySession(subject, sessionType);
  closeModal(); renderToday();
  if (evt) toast(`Logged ${fmtMinutes(evt.durationMin)} of ${subject}`);
}

/* ===================== URGE / INTERVENTION flow ===================== */
function openUrgeFlow() {
  openModal(`
    <h2 class="modal-title">How strong is the urge?</h2>
    <div class="intensity-row" id="intensity-row">
      ${[1,2,3,4,5,6,7,8,9,10].map(n => `<button class="intensity-btn" data-val="${n}">${n}</button>`).join('')}
    </div>
  `, (root) => {
    root.querySelector('#intensity-row').addEventListener('click', (e) => {
      const btn = e.target.closest('.intensity-btn'); if (!btn) return;
      const intensity = Number(btn.dataset.val);
      const evt = addEvent({ type: 'urge', intensity });
      renderToday();
      if (intensity >= 7) openHighUrgeProtocol(evt.id);
      else { closeModal(); toast('Urge logged'); }
    });
  });
}
function openHighUrgeProtocol(urgeEventId) {
  openModal(`
    <h2 class="modal-title">⚡ High urge</h2>
    <p class="modal-subtitle">Don't negotiate with it. Change your environment.</p>
    <div class="quick-grid" id="protocol-grid">
      ${INTERVENTIONS.map(i => `<button class="quick-opt" data-label="${escapeHtml(i.label)}"><span class="em">${i.em}</span> ${escapeHtml(i.label)}</button>`).join('')}
    </div>
    <button class="modal-btn ghost" id="skip-protocol-btn">Skip for now</button>
  `, (root) => {
    root.querySelector('#protocol-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      const iv = addEvent({ type: 'intervention', urgeEventId, intervention: btn.dataset.label, postIntensity: null });
      openPostInterventionCheck(iv.id);
    });
    root.querySelector('#skip-protocol-btn').addEventListener('click', closeModal);
  });
}
function openPostInterventionCheck(interventionId) {
  openModal(`
    <h2 class="modal-title">Urge now?</h2>
    <p class="modal-subtitle">Optional — helps Steadfast learn what works for you.</p>
    <div class="intensity-row" id="post-intensity-row">
      ${[1,2,3,4,5,6,7,8,9,10].map(n => `<button class="intensity-btn" data-val="${n}">${n}</button>`).join('')}
    </div>
    <button class="modal-btn secondary" id="skip-post-btn">Skip</button>
  `, (root) => {
    root.querySelector('#post-intensity-row').addEventListener('click', (e) => {
      const btn = e.target.closest('.intensity-btn'); if (!btn) return;
      updateEvent(interventionId, { postIntensity: Number(btn.dataset.val) });
      closeModal(); renderToday(); toast('Nice work.');
    });
    root.querySelector('#skip-post-btn').addEventListener('click', () => { closeModal(); renderToday(); });
  });
}

/* ===================== SLIP flow ===================== */
function openSlipFlow() {
  openModal(`
    <h2 class="modal-title">What triggered it?</h2>
    <p class="modal-subtitle">One tap is enough. This doesn't undo the rest of today.</p>
    <div class="chip-row" id="slip-trigger-row">
      ${state.settings.triggers.map(t => `<button class="chip" data-trigger="${escapeHtml(t)}">${escapeHtml(t)}</button>`).join('')}
    </div>
    <button class="modal-btn secondary" id="skip-slip-trigger" style="margin-top:14px;">Skip</button>
  `, (root) => {
    root.querySelector('#slip-trigger-row').addEventListener('click', (e) => {
      const chip = e.target.closest('.chip'); if (!chip) return;
      finishSlip(chip.dataset.trigger);
    });
    root.querySelector('#skip-slip-trigger').addEventListener('click', () => finishSlip(null));
  });
}
function finishSlip(trigger) {
  addEvent({ type: 'slip', trigger });
  renderToday();
  openPostSlipRecovery();
}
function openPostSlipRecovery() {
  openModal(`
    <h2 class="modal-title">Okay. It happened.</h2>
    <p class="modal-subtitle">What happens next matters.</p>
    <ol class="protocol-list">
      <li><span class="num">1</span> Leave the trigger environment.</li>
      <li><span class="num">2</span> Put your phone away.</li>
      <li><span class="num">3</span> Drink some water.</li>
      <li><span class="num">4</span> Do 10 minutes of something productive.</li>
      <li><span class="num">5</span> Continue your day.</li>
    </ol>
    <button class="modal-btn" id="im-back-btn">I'm back</button>
  `, (root) => {
    root.querySelector('#im-back-btn').addEventListener('click', closeModal);
  });
}

/* ===================== WORKOUT / MEDITATION / MOOD / WATER / SLEEP / STEPS ===================== */
function openWorkoutFlow() {
  openModal(`
    <h2 class="modal-title">💪 Workout</h2>
    <p class="modal-subtitle">What kind? Optional.</p>
    <div class="quick-grid" id="workout-grid">
      ${WORKOUT_TYPES.map(t => `<button class="quick-opt" data-type="${escapeHtml(t)}">${escapeHtml(t)}</button>`).join('')}
    </div>
    <button class="modal-btn secondary" id="skip-workout-type">Just log it done</button>
  `, (root) => {
    root.querySelector('#workout-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      addEvent({ type: 'workout', workoutType: btn.dataset.type });
      closeModal(); renderToday(); toast('Workout logged');
    });
    root.querySelector('#skip-workout-type').addEventListener('click', () => {
      addEvent({ type: 'workout', workoutType: null });
      closeModal(); renderToday(); toast('Workout logged');
    });
  });
}
function openMeditationFlow() {
  openModal(`
    <h2 class="modal-title">🧘 Meditation</h2>
    <div class="quick-grid cols-3" id="med-grid">
      ${[2,5,10,20].map(m => `<button class="quick-opt" data-min="${m}">${m} min</button>`).join('')}
      <button class="quick-opt" data-min="0">Just done</button>
    </div>
  `, (root) => {
    root.querySelector('#med-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      const min = Number(btn.dataset.min);
      addEvent({ type: 'meditation', durationMin: min || null });
      closeModal(); renderToday(); toast('Meditation logged');
    });
  });
}
function openMoodFlow() {
  openModal(`
    <h2 class="modal-title">How are you feeling?</h2>
    <div class="quick-grid cols-3" id="mood-grid" style="margin-bottom:14px;">
      ${MOODS.map(m => `<button class="quick-opt" data-val="${m.value}" style="justify-content:center;font-size:24px;">${m.em}</button>`).join('')}
    </div>
    <p class="field-label">Energy (optional)</p>
    <div class="intensity-row" id="energy-row">
      ${[1,2,3,4,5].map(n => `<button class="intensity-btn" data-val="${n}">${n}</button>`).join('')}
    </div>
    <button class="modal-btn secondary" id="skip-energy-btn">Save mood only</button>
  `, (root) => {
    let moodVal = null;
    root.querySelector('#mood-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      moodVal = Number(btn.dataset.val);
      root.querySelectorAll('#mood-grid .quick-opt').forEach(b => b.classList.toggle('selected', b === btn));
    });
    root.querySelector('#energy-row').addEventListener('click', (e) => {
      const btn = e.target.closest('.intensity-btn'); if (!btn) return;
      if (moodVal == null) { toast('Pick a mood first'); return; }
      addEvent({ type: 'mood', value: moodVal });
      addEvent({ type: 'energy', value: Number(btn.dataset.val) });
      closeModal(); renderToday(); toast('Logged');
    });
    root.querySelector('#skip-energy-btn').addEventListener('click', () => {
      if (moodVal == null) { toast('Pick a mood first'); return; }
      addEvent({ type: 'mood', value: moodVal });
      closeModal(); renderToday(); toast('Mood logged');
    });
  });
}
function openWaterFlow() {
  openModal(`
    <h2 class="modal-title">💧 Water</h2>
    <div class="quick-grid cols-3" id="water-grid">
      ${[0.25,0.5,1].map(l => `<button class="quick-opt" data-l="${l}">+${l}L</button>`).join('')}
    </div>
  `, (root) => {
    root.querySelector('#water-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      addEvent({ type: 'water', amountL: Number(btn.dataset.l) });
      closeModal(); renderToday(); toast('Water logged');
    });
  });
}
function openSleepFlow() {
  openModal(`
    <h2 class="modal-title">😴 Sleep</h2>
    <div class="quick-grid" id="sleep-grid">
      ${SLEEP_OPTIONS.map(o => `<button class="quick-opt" data-val="${o.value}">${o.label}</button>`).join('')}
    </div>
    <p class="field-label" style="margin-top:14px;">Exact hours (optional)</p>
    <input type="number" step="0.25" min="0" max="14" class="text-input" id="sleep-exact" placeholder="e.g. 7.5">
    <button class="modal-btn secondary" id="save-exact-sleep">Save exact</button>
  `, (root) => {
    root.querySelector('#sleep-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      addEvent({ type: 'sleep', hours: Number(btn.dataset.val) });
      closeModal(); renderToday(); toast('Sleep logged');
    });
    root.querySelector('#save-exact-sleep').addEventListener('click', () => {
      const v = parseFloat(root.querySelector('#sleep-exact').value);
      if (!v) return;
      addEvent({ type: 'sleep', hours: v });
      closeModal(); renderToday(); toast('Sleep logged');
    });
  });
}
function openStepsFlow() {
  openModal(`
    <h2 class="modal-title">🚶 Steps</h2>
    <input type="number" min="0" class="text-input" id="steps-input" placeholder="e.g. 6500">
    <button class="modal-btn" id="save-steps-btn">Save</button>
  `, (root) => {
    root.querySelector('#save-steps-btn').addEventListener('click', () => {
      const v = parseInt(root.querySelector('#steps-input').value, 10);
      if (Number.isNaN(v)) return;
      addEvent({ type: 'steps', count: v });
      closeModal(); renderToday(); toast('Steps logged');
    });
  });
}
function openHabitQuickFlow() {
  const agg = computeDayAggregate(todayKey());
  openModal(`
    <h2 class="modal-title">✓ Mark a habit done</h2>
    <div class="quick-grid" id="habit-quick-grid">
      ${state.habits.map(h => `<button class="quick-opt ${agg.habitDone[h.id] ? 'selected' : ''}" data-id="${h.id}">${escapeHtml(h.name)}</button>`).join('')}
    </div>
    ${!state.habits.length ? '<p class="empty-note">No habits yet — add some in the Habits tab.</p>' : ''}
  `, (root) => {
    root.querySelector('#habit-quick-grid').addEventListener('click', (e) => {
      const btn = e.target.closest('.quick-opt'); if (!btn) return;
      addEvent({ type: 'habit', habitId: btn.dataset.id, value: true });
      closeModal(); renderToday(); toast('Habit logged');
    });
  });
}
function openNoteFlow() {
  openModal(`
    <h2 class="modal-title">📝 Note</h2>
    <textarea class="notes-input" id="note-text" rows="4" placeholder="Anything worth remembering..."></textarea>
    <button class="modal-btn" id="save-note-btn">Save</button>
  `, (root) => {
    root.querySelector('#save-note-btn').addEventListener('click', () => {
      const text = root.querySelector('#note-text').value.trim();
      if (!text) { closeModal(); return; }
      addEvent({ type: 'note', text });
      closeModal(); toast('Note saved');
    });
  });
}

/* ===================== Recovery detail ===================== */
function openRecoveryDetail() {
  const current = computeCurrentStreak();
  const best = computeBestStreak();
  openModal(`
    <h2 class="modal-title">🔥 Recovery</h2>
    <p class="modal-subtitle">Current streak <b>${current}</b> day${current === 1 ? '' : 's'} · Best <b>${best}</b></p>
    <div class="quick-grid" style="margin-bottom:14px;">
      <button class="quick-opt" id="log-urge-btn2">🔥 Log urge</button>
      <button class="quick-opt" id="log-slip-btn2">🚨 Slipped</button>
      <button class="quick-opt" id="mark-rest-btn">😌 Mark today rest</button>
    </div>
    <button class="modal-btn secondary" id="close-recovery-btn">Close</button>
  `, (root) => {
    root.querySelector('#mark-rest-btn').addEventListener('click', () => {
      state.days[todayKey()] = { recoveryOverride: 'REST' };
      saveState(); closeModal(); renderToday();
    });
    root.querySelector('#log-urge-btn2').addEventListener('click', () => { closeModal(); openUrgeFlow(); });
    root.querySelector('#log-slip-btn2').addEventListener('click', () => { closeModal(); openSlipFlow(); });
    root.querySelector('#close-recovery-btn').addEventListener('click', closeModal);
  });
}

/* ===================== TODAY screen render ===================== */
function renderToday() {
  document.getElementById('today-date').textContent = longDateLabel(new Date());
  const score = computeDisciplineScore(todayKey());
  document.getElementById('score-num').textContent = score;

  const agg = computeDayAggregate(todayKey());
  const current = computeCurrentStreak();
  const settings = state.settings;

  const statusMap = {
    ON_TRACK: ['🟢 On track', ''],
    REST: ['😌 Rest day', 'rest'],
    SLIPPED: ['Slipped', 'slipped'],
  };
  const [statusLabel, statusClass] = statusMap[agg.recoveryStatus];

  const studyPct = Math.min(100, Math.round((agg.studyMin / settings.studyDailyTarget) * 100));
  let studyTier = '';
  if (agg.studyMin >= settings.studyDailyExcellent) studyTier = '⭐ Excellent';
  else if (agg.studyMin >= settings.studyDailyTarget) studyTier = '🟢 Target hit';
  else if (agg.studyMin >= settings.studyDailyMin) studyTier = '🟡 Minimum done';
  else studyTier = agg.studyMin > 0 ? '🔴 Below minimum' : '';

  const habitsScheduled = habitsScheduledOn(todayKey());

  const html = `
    <div class="pillar-card" id="recovery-card">
      <div class="pillar-head">
        <span class="pillar-title"><span class="em">🔥</span> Recovery</span>
        <span class="pillar-status-pill ${statusClass}">${statusLabel}</span>
      </div>
      <p class="pillar-sub">${current} day streak</p>
      <div class="pillar-actions">
        <button class="pillar-btn primary" id="log-urge-btn">+ Urge</button>
        <button class="pillar-btn" id="log-slip-btn">🚨 Slipped</button>
      </div>
    </div>

    <div class="pillar-card" id="study-card">
      <div class="pillar-head">
        <span class="pillar-title"><span class="em">📚</span> Study</span>
        ${state.activeSession && state.activeSession.pomodoro ? `<span class="pillar-status-pill">🍅 Pomodoro · ${state.activeSession.pomodoro.phase === 'work' ? 'Work' : 'Break'}</span>` : (studyTier ? `<span class="pillar-status-pill">${studyTier}</span>` : '')}
      </div>
      <div class="pillar-big">${fmtMinutes(agg.studyMin)} <span style="font-size:16px;color:var(--text-faint);font-family:var(--font-body);">/ ${fmtMinutes(settings.studyDailyTarget)}</span></div>
      <div class="pillar-progress-track"><div class="pillar-progress-fill" style="width:${studyPct}%"></div></div>
      <div class="pillar-actions">
        <button class="pillar-btn ${state.activeSession ? 'timer-active' : 'study-primary'}" id="study-action-btn">
          ${state.activeSession ? (state.activeSession.isPaused ? '⏸ Paused — tap to resume' : '⏱ Studying — tap to open') : '▶ Start study'}
        </button>
      </div>
    </div>

    <p class="section-label">💪 Body</p>
    <div class="mini-grid" style="margin-bottom:12px;">
      <div class="mini-stat" id="workout-stat">
        <div class="mini-stat-head"><span class="mini-stat-label">Workout</span>
          <div class="mini-stat-check ${agg.workoutDone ? 'checked' : ''}"></div>
        </div>
        <div class="mini-stat-value muted">${agg.workoutDone ? (agg.workoutEvents[0].workoutType || 'Done') : 'Not yet'}</div>
      </div>
      <div class="mini-stat" id="sleep-stat">
        <div class="mini-stat-head"><span class="mini-stat-label">Sleep</span></div>
        <div class="mini-stat-value">${agg.sleep != null ? agg.sleep + 'h' : '—'}</div>
      </div>
      <div class="mini-stat" id="water-stat">
        <div class="mini-stat-head"><span class="mini-stat-label">Water</span></div>
        <div class="mini-stat-value">${agg.water.toFixed(agg.water % 1 === 0 ? 0 : 2)}<span style="font-size:13px;color:var(--text-faint);"> / ${settings.waterDailyTarget}L</span></div>
      </div>
      <div class="mini-stat" id="steps-stat">
        <div class="mini-stat-head"><span class="mini-stat-label">Steps</span></div>
        <div class="mini-stat-value">${agg.steps != null ? agg.steps.toLocaleString() : '—'}</div>
      </div>
    </div>

    <p class="section-label">🧠 Mind</p>
    <div class="mini-grid" style="margin-bottom:12px;">
      <div class="mini-stat" id="mood-stat">
        <div class="mini-stat-head"><span class="mini-stat-label">Mood</span></div>
        <div class="mini-stat-value" style="font-size:22px;">${agg.mood != null ? MOODS.find(m => m.value === agg.mood).em + ' ' + agg.mood + '/5' : '—'}</div>
      </div>
      <div class="mini-stat" id="meditation-stat">
        <div class="mini-stat-head"><span class="mini-stat-label">Meditation</span>
          <div class="mini-stat-check ${agg.meditationDone ? 'checked' : ''}"></div>
        </div>
        <div class="mini-stat-value muted">${agg.meditationDone ? 'Done' : 'Not yet'}</div>
      </div>
    </div>

    <p class="section-label">🌱 Habits</p>
    <div class="card" style="margin-bottom:12px;">
      <div class="habit-checklist" id="today-habit-list">
        ${habitsScheduled.length ? habitsScheduled.map(h => `
          <div class="habit-row">
            <button type="button" class="habit-check ${agg.habitDone[h.id] ? 'checked' : ''}" data-id="${h.id}" aria-label="Mark ${escapeHtml(h.name)} done"></button>
            <span class="habit-name">${escapeHtml(h.name)}</span>
          </div>
        `).join('') : '<p class="empty-note">No habits yet — add some in the Habits tab.</p>'}
      </div>
    </div>
  `;
  document.getElementById('today-content').innerHTML = html;

  // wire events
  document.getElementById('recovery-card').addEventListener('click', (e) => {
    if (e.target.closest('#log-urge-btn') || e.target.closest('#log-slip-btn')) return;
    openRecoveryDetail();
  });
  document.getElementById('log-urge-btn').addEventListener('click', (e) => { e.stopPropagation(); openUrgeFlow(); });
  document.getElementById('log-slip-btn').addEventListener('click', (e) => { e.stopPropagation(); openSlipFlow(); });

  document.getElementById('study-card').addEventListener('click', (e) => {
    if (e.target.closest('#study-action-btn')) return;
    openStudyFlow();
  });
  document.getElementById('study-action-btn').addEventListener('click', (e) => { e.stopPropagation(); openStudyFlow(); });

  document.getElementById('workout-stat').addEventListener('click', openWorkoutFlow);
  document.getElementById('sleep-stat').addEventListener('click', openSleepFlow);
  document.getElementById('water-stat').addEventListener('click', openWaterFlow);
  document.getElementById('steps-stat').addEventListener('click', openStepsFlow);
  document.getElementById('mood-stat').addEventListener('click', openMoodFlow);
  document.getElementById('meditation-stat').addEventListener('click', openMeditationFlow);

  document.getElementById('today-habit-list').querySelectorAll('.habit-check').forEach(btn => {
    btn.addEventListener('click', () => {
      const habitId = btn.dataset.id;
      const already = btn.classList.contains('checked');
      addEvent({ type: 'habit', habitId, value: !already });
      renderToday();
    });
  });
}

/* ===================== CALENDAR screen ===================== */
let calendarCursor = new Date();
calendarCursor.setDate(1);

function renderCalendar() {
  document.getElementById('month-label').textContent = calendarCursor.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  const grid = document.getElementById('month-grid');
  grid.innerHTML = '';

  const year = calendarCursor.getFullYear(), month = calendarCursor.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const todayStr = todayKey();

  for (let i = 0; i < firstDay; i++) {
    const cell = document.createElement('div');
    cell.className = 'day-cell empty';
    grid.appendChild(cell);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    const d = new Date(year, month, day);
    const key = fmtDate(d);
    if (d > new Date()) {
      const cell = document.createElement('div');
      cell.className = 'day-cell empty';
      grid.appendChild(cell);
      continue;
    }
    const agg = computeDayAggregate(key);
    const cell = document.createElement('div');
    cell.className = 'day-cell';
    if (agg.recoveryStatus === 'SLIPPED') cell.classList.add('slipped');
    else if (agg.recoveryStatus === 'REST') cell.classList.add('rest');
    if (key === todayStr) cell.classList.add('today');

    const dots = [];
    if (agg.studyMin > 0) dots.push('<span class="day-dot violet"></span>');
    if (agg.workoutDone) dots.push('<span class="day-dot"></span>');
    if (agg.slipCount > 0) dots.push('<span class="day-dot amber"></span>');

    cell.innerHTML = `<span>${day}</span><span class="day-dots">${dots.slice(0, 3).join('')}</span>`;
    cell.addEventListener('click', () => showDayDetail(key, d));
    grid.appendChild(cell);
  }
  document.getElementById('day-detail-card').hidden = true;
}

function showDayDetail(key, d) {
  const agg = computeDayAggregate(key);
  const evts = eventsForDate(key).slice().sort((a, b) => a.ts - b.ts);
  const card = document.getElementById('day-detail-card');
  document.getElementById('day-detail-title').textContent = longDateLabel(d);
  const body = document.getElementById('day-detail-body');

  if (!evts.length && agg.recoveryStatus === 'ON_TRACK') {
    body.innerHTML = '<p class="empty-note">No events logged — quiet, on-track day.</p>';
    card.hidden = false;
    return;
  }

  const summaryBits = [];
  if (agg.studyMin > 0) summaryBits.push(`📚 ${fmtMinutes(agg.studyMin)}`);
  summaryBits.push(agg.recoveryStatus === 'SLIPPED' ? '🚨 Slipped' : (agg.recoveryStatus === 'REST' ? '😌 Rest' : '🟢 On track'));
  if (agg.workoutDone) summaryBits.push('💪 Workout');
  if (agg.mood != null) summaryBits.push(`${MOODS.find(m => m.value === agg.mood).em} ${agg.mood}/5`);

  const eventLines = evts.map(e => {
    let label = '';
    switch (e.type) {
      case 'study': label = `📚 Study — ${e.subject || 'Other'} (${fmtMinutes(e.durationMin)})`; break;
      case 'urge': label = `🔥 Urge ${e.intensity}/10`; break;
      case 'intervention': label = `🧭 ${e.intervention}${e.postIntensity != null ? ' → urge ' + e.postIntensity + '/10 after' : ''}`; break;
      case 'slip': label = `🚨 Slip${e.trigger ? ' — ' + e.trigger : ''}`; break;
      case 'workout': label = `💪 Workout${e.workoutType ? ' — ' + e.workoutType : ''}`; break;
      case 'meditation': label = `🧘 Meditation${e.durationMin ? ' (' + e.durationMin + 'm)' : ''}`; break;
      case 'mood': label = `${MOODS.find(m => m.value === e.value).em} Mood ${e.value}/5`; break;
      case 'energy': label = `⚡ Energy ${e.value}/5`; break;
      case 'water': label = `💧 +${e.amountL}L`; break;
      case 'steps': label = `🚶 ${e.count.toLocaleString()} steps`; break;
      case 'sleep': label = `😴 ${e.hours}h sleep`; break;
      case 'habit': {
        const h = state.habits.find(hh => hh.id === e.habitId);
        label = `✓ ${h ? h.name : 'Habit'}`;
        break;
      }
      case 'note': label = `📝 ${e.text}`; break;
      default: label = e.type;
    }
    return `<div class="day-event-line"><span class="day-event-time">${timeLabel(e.ts)}</span><span>${escapeHtml(label)}</span></div>`;
  }).join('');

  body.innerHTML = `<p style="margin:0 0 12px;">${summaryBits.join(' · ')}</p>${eventLines || '<p class="empty-note">No individual events.</p>'}`;
  card.hidden = false;
}

document.getElementById('month-prev').addEventListener('click', () => { calendarCursor.setMonth(calendarCursor.getMonth() - 1); renderCalendar(); });
document.getElementById('month-next').addEventListener('click', () => { calendarCursor.setMonth(calendarCursor.getMonth() + 1); renderCalendar(); });

/* ===================== INSIGHTS screen ===================== */
let insightRange = 30;

function daysArray(n) {
  const days = [];
  const instKey = installedDateKey();
  for (let i = n - 1; i >= 0; i--) {
    const d = addDays(new Date(), -i);
    const key = fmtDate(d);
    if (key < instKey) continue; // the app wasn't installed yet — don't count as "on track"
    days.push({ key, d, agg: computeDayAggregate(key) });
  }
  return days;
}

function renderInsights() {
  const days = daysArray(insightRange);
  const container = document.getElementById('insights-content');

  const slipDays = days.filter(x => x.agg.recoveryStatus === 'SLIPPED');
  const onTrackDays = days.filter(x => x.agg.recoveryStatus !== 'SLIPPED');
  const percent = days.length ? Math.round((onTrackDays.length / days.length) * 100) : 0;

  const allUrgeEvents = eventsInRange(days[0].d, new Date()).filter(e => e.type === 'urge');
  const avgUrge = allUrgeEvents.length ? (allUrgeEvents.reduce((s, e) => s + e.intensity, 0) / allUrgeEvents.length).toFixed(1) : '—';

  const totalStudyMin = days.reduce((s, x) => s + x.agg.studyMin, 0);
  const studyDays = days.filter(x => x.agg.studyMin > 0);
  const dailyAvgStudy = days.length ? totalStudyMin / days.length : 0;
  const allStudyEvents = eventsInRange(days[0].d, new Date()).filter(e => e.type === 'study');
  const longestSession = allStudyEvents.length ? Math.max(...allStudyEvents.map(e => e.durationMin)) : 0;
  const bestDay = days.slice().sort((a, b) => b.agg.studyMin - a.agg.studyMin)[0];

  const subjectTally = {};
  allStudyEvents.forEach(e => { subjectTally[e.subject || 'Other'] = (subjectTally[e.subject || 'Other'] || 0) + e.durationMin; });

  const workoutDays = days.filter(x => x.agg.workoutDone).length;
  const sleepVals = days.filter(x => x.agg.sleep != null).map(x => x.agg.sleep);
  const sleepAvg = sleepVals.length ? (sleepVals.reduce((a, b) => a + b, 0) / sleepVals.length).toFixed(1) : '—';
  const moodVals = days.filter(x => x.agg.mood != null).map(x => x.agg.mood);
  const moodAvg = moodVals.length ? (moodVals.reduce((a, b) => a + b, 0) / moodVals.length).toFixed(1) : '—';
  const energyVals = days.filter(x => x.agg.energy != null).map(x => x.agg.energy);
  const energyAvg = energyVals.length ? (energyVals.reduce((a, b) => a + b, 0) / energyVals.length).toFixed(1) : '—';

  // trigger + intervention frequency
  const rangeEvents = eventsInRange(days[0].d, new Date());
  const triggerTally = {};
  rangeEvents.filter(e => e.type === 'slip' && e.trigger).forEach(e => { triggerTally[e.trigger] = (triggerTally[e.trigger] || 0) + 1; });
  const interventionEvents = rangeEvents.filter(e => e.type === 'intervention');
  const interventionTally = {};
  interventionEvents.forEach(e => { interventionTally[e.intervention] = (interventionTally[e.intervention] || 0) + 1; });

  // intervention effectiveness: avg reduction (pre-urge intensity vs post)
  const effectivenessByIntervention = {};
  interventionEvents.forEach(e => {
    if (e.postIntensity == null) return;
    const urgeEvt = rangeEvents.find(u => u.id === e.urgeEventId) || state.events.find(u => u.id === e.urgeEventId);
    if (!urgeEvt) return;
    const reduction = urgeEvt.intensity - e.postIntensity;
    if (!effectivenessByIntervention[e.intervention]) effectivenessByIntervention[e.intervention] = [];
    effectivenessByIntervention[e.intervention].push(reduction);
  });

  // weekly dashboard (current calendar week, Sun-Sat)
  const weekStart = startOfWeek(new Date());
  const weekDays = [];
  for (let i = 0; i < 7; i++) weekDays.push(fmtDate(addDays(weekStart, i)));
  const weekAggs = weekDays.map(k => computeDayAggregate(k));
  const weekStudyMin = weekAggs.reduce((s, a) => s + a.studyMin, 0);
  const weekCleanDays = cleanDaysInRange(weekStart, new Date());
  const weekWorkouts = weekAggs.filter(a => a.workoutDone).length;
  const weekMeditations = weekAggs.filter(a => a.meditationDone).length;
  const weekMoodVals = weekAggs.filter(a => a.mood != null).map(a => a.mood);
  const weekMoodAvg = weekMoodVals.length ? (weekMoodVals.reduce((a, b) => a + b, 0) / weekMoodVals.length).toFixed(1) : null;
  const weekHabitScheduled = weekDays.reduce((s, k) => s + habitsScheduledOn(k).length, 0);
  const weekHabitDone = weekDays.reduce((s, k) => s + Object.values(computeDayAggregate(k).habitDone).filter(Boolean).length, 0);
  const habitConsistency = weekHabitScheduled ? Math.round((weekHabitDone / weekHabitScheduled) * 100) : null;

  // today vs yesterday
  const todayAgg = computeDayAggregate(todayKey());
  const yestAgg = computeDayAggregate(fmtDate(addDays(new Date(), -1)));

  // bar chart data (sample if range large)
  const chartDays = insightRange <= 30 ? days : days.filter((_, i) => i % 3 === 0);

  // correlation observations (need minimum samples)
  const observations = buildObservations(days, rangeEvents);

  container.innerHTML = `
    <div class="card">
      <h2 class="card-title">This week</h2>
      <div class="week-row"><span class="week-icon">📚</span>
        <div class="week-info"><div class="week-name">Study</div>
          <div class="week-track"><div class="week-fill" style="width:${Math.min(100, (weekStudyMin / (state.settings.studyWeeklyTarget || 1)) * 100)}%"></div></div>
        </div>
        <span class="week-value">${fmtMinutes(weekStudyMin)} / ${fmtMinutes(state.settings.studyWeeklyTarget)}</span>
      </div>
      <div class="week-row"><span class="week-icon">🔥</span>
        <div class="week-info"><div class="week-name">Recovery</div>
          <div class="week-track"><div class="week-fill" style="width:${Math.round((weekCleanDays / 7) * 100)}%"></div></div>
        </div>
        <span class="week-value">${weekCleanDays} clean days</span>
      </div>
      <div class="week-row"><span class="week-icon">💪</span>
        <div class="week-info"><div class="week-name">Workout</div>
          <div class="week-track"><div class="week-fill" style="width:${Math.min(100, (weekWorkouts / (state.settings.workoutWeeklyTarget || 1)) * 100)}%"></div></div>
        </div>
        <span class="week-value">${weekWorkouts} / ${state.settings.workoutWeeklyTarget}</span>
      </div>
      ${weekMoodAvg ? `
      <div class="week-row"><span class="week-icon">🙂</span>
        <div class="week-info"><div class="week-name">Mood avg</div>
          <div class="week-track"><div class="week-fill" style="width:${(weekMoodAvg / 5) * 100}%"></div></div>
        </div>
        <span class="week-value">${weekMoodAvg} / 5</span>
      </div>` : ''}
      ${habitConsistency != null ? `
      <div class="week-row"><span class="week-icon">🌱</span>
        <div class="week-info"><div class="week-name">Habits</div>
          <div class="week-track"><div class="week-fill" style="width:${habitConsistency}%"></div></div>
        </div>
        <span class="week-value">${habitConsistency}%</span>
      </div>` : ''}
    </div>

    <div class="card">
      <h2 class="card-title">Today vs yesterday</h2>
      <div class="compare-row"><span class="compare-name">Study</span>
        <span class="compare-values">
          <span class="compare-today">${fmtMinutes(todayAgg.studyMin)}</span>
          <span class="compare-yesterday ${todayAgg.studyMin > yestAgg.studyMin ? 'trend-up' : (todayAgg.studyMin < yestAgg.studyMin ? 'trend-down' : '')}">${fmtMinutes(yestAgg.studyMin)} yesterday</span>
        </span>
      </div>
      <div class="compare-row"><span class="compare-name">Workout</span>
        <span class="compare-values">
          <span class="compare-today">${todayAgg.workoutDone ? '✓' : '—'}</span>
          <span class="compare-yesterday">${yestAgg.workoutDone ? '✓' : '—'} yesterday</span>
        </span>
      </div>
      <div class="compare-row"><span class="compare-name">Recovery</span>
        <span class="compare-values">
          <span class="compare-today">${todayAgg.recoveryStatus === 'SLIPPED' ? 'Slipped' : 'On track'}</span>
          <span class="compare-yesterday">${yestAgg.recoveryStatus === 'SLIPPED' ? 'Slipped' : 'On track'} yesterday</span>
        </span>
      </div>
    </div>

    <p class="section-label">🔥 Recovery</p>
    <div class="stat-grid">
      <div class="stat-card"><span class="stat-value">${percent}%</span><span class="stat-label">days on track</span></div>
      <div class="stat-card"><span class="stat-value">${slipDays.length}</span><span class="stat-label">slips</span></div>
      <div class="stat-card"><span class="stat-value">${allUrgeEvents.length}</span><span class="stat-label">urges logged</span></div>
      <div class="stat-card"><span class="stat-value">${avgUrge}</span><span class="stat-label">avg intensity</span></div>
    </div>
    <div class="card">
      <h2 class="card-title">Most common triggers</h2>
      <div class="freq-list">${freqListHtml(triggerTally)}</div>
    </div>
    <div class="card">
      <h2 class="card-title">Interventions used</h2>
      <div class="freq-list">${freqListHtml(interventionTally)}</div>
      ${Object.keys(effectivenessByIntervention).length ? `<div style="margin-top:14px;">${
        Object.entries(effectivenessByIntervention).map(([name, arr]) => {
          const avg = (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(1);
          return `<p class="insight-note">Your logged data suggests <b>${escapeHtml(name)}</b> reduced urge intensity by an average of <b>${avg}</b> point${avg == 1 ? '' : 's'} (${arr.length} use${arr.length === 1 ? '' : 's'}).</p>`;
        }).join('')
      }</div>` : ''}
    </div>

    <p class="section-label">📚 Study</p>
    <div class="stat-grid">
      <div class="stat-card"><span class="stat-value">${fmtMinutes(totalStudyMin)}</span><span class="stat-label">total time</span></div>
      <div class="stat-card"><span class="stat-value">${fmtMinutes(dailyAvgStudy)}</span><span class="stat-label">daily average</span></div>
      <div class="stat-card"><span class="stat-value">${allStudyEvents.length}</span><span class="stat-label">sessions</span></div>
      <div class="stat-card"><span class="stat-value">${fmtMinutes(longestSession)}</span><span class="stat-label">longest session</span></div>
    </div>
    <div class="card">
      <h2 class="card-title">Daily study pattern</h2>
      <div class="bar-chart">
        ${chartDays.map(x => `
          <div class="bar-col">
            <div class="bar" style="height:${Math.max(4, Math.min(100, (x.agg.studyMin / (state.settings.studyDailyExcellent || 1)) * 100))}%; background:${x.agg.studyMin > 0 ? 'var(--c-primary)' : 'var(--border)'};"></div>
            ${insightRange <= 7 ? `<span class="bar-day-label">${x.d.toLocaleDateString(undefined,{weekday:'short'})[0]}</span>` : ''}
          </div>
        `).join('')}
      </div>
    </div>
    <div class="card">
      <h2 class="card-title">Subject distribution</h2>
      <div class="freq-list">${freqListHtml(Object.fromEntries(Object.entries(subjectTally).map(([k, v]) => [k, Math.round(v)])))}</div>
    </div>
    ${bestDay && bestDay.agg.studyMin > 0 ? `<p class="insight-note">Best study day: <b>${shortDateLabel(bestDay.d)}</b> with ${fmtMinutes(bestDay.agg.studyMin)}.</p>` : ''}

    <p class="section-label">💪 Body &amp; 🧠 Mind</p>
    <div class="stat-grid">
      <div class="stat-card"><span class="stat-value">${workoutDays}</span><span class="stat-label">workout days</span></div>
      <div class="stat-card"><span class="stat-value">${sleepAvg}</span><span class="stat-label">avg sleep (h)</span></div>
      <div class="stat-card"><span class="stat-value">${moodAvg}</span><span class="stat-label">avg mood /5</span></div>
      <div class="stat-card"><span class="stat-value">${energyAvg}</span><span class="stat-label">avg energy /5</span></div>
    </div>

    ${observations.length ? `
    <p class="section-label">Observed patterns</p>
    ${observations.map(o => `<p class="insight-note">${o}</p>`).join('')}
    ` : `<p class="empty-note">Keep logging a little longer and Steadfast will start detecting patterns.</p>`}
  `;
}

function freqListHtml(tally) {
  const entries = Object.entries(tally).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
  if (!entries.length) return '<p class="empty-note">Not enough data yet.</p>';
  const max = Math.max(...entries.map(e => e[1]));
  return entries.map(([name, count]) => `
    <div class="freq-row">
      <span class="freq-name">${escapeHtml(name)}</span>
      <span class="freq-bar-track"><span class="freq-bar-fill" style="width:${(count / max) * 100}%"></span></span>
      <span class="freq-count">${count}</span>
    </div>
  `).join('');
}

function buildObservations(days, rangeEvents) {
  const MIN_SAMPLE = 5;
  const obs = [];

  // time-of-day for urges/slips
  const riskEvents = rangeEvents.filter(e => e.type === 'urge' || e.type === 'slip');
  if (riskEvents.length >= MIN_SAMPLE) {
    const hourBuckets = { late: 0, evening: 0, day: 0, morning: 0 };
    riskEvents.forEach(e => {
      const h = new Date(e.ts).getHours();
      if (h >= 22 || h < 2) hourBuckets.late++;
      else if (h >= 18) hourBuckets.evening++;
      else if (h >= 6) hourBuckets.day++;
      else hourBuckets.morning++;
    });
    const top = Object.entries(hourBuckets).sort((a, b) => b[1] - a[1])[0];
    const labels = { late: 'late night (10PM–2AM)', evening: 'evening (6–10PM)', day: 'daytime', morning: 'early morning' };
    if (top[1] / riskEvents.length >= 0.4) {
      obs.push(`In your logged data, urges and slips are most common during <b>${labels[top[0]]}</b>.`);
    }
  }

  // most common trigger
  const triggerCounts = {};
  rangeEvents.filter(e => e.type === 'slip' && e.trigger).forEach(e => { triggerCounts[e.trigger] = (triggerCounts[e.trigger] || 0) + 1; });
  const triggerEntries = Object.entries(triggerCounts).sort((a, b) => b[1] - a[1]);
  if (triggerEntries.length && triggerEntries[0][1] >= 3) {
    obs.push(`<b>${escapeHtml(triggerEntries[0][0])}</b> is your most commonly logged trigger (${triggerEntries[0][1]} times).`);
  }

  // mood vs study days
  const studyDayKeys = new Set(days.filter(x => x.agg.studyMin >= 60).map(x => x.key));
  const moodOnStudyDays = days.filter(x => studyDayKeys.has(x.key) && x.agg.mood != null).map(x => x.agg.mood);
  const moodOnOtherDays = days.filter(x => !studyDayKeys.has(x.key) && x.agg.mood != null).map(x => x.agg.mood);
  if (moodOnStudyDays.length >= 3 && moodOnOtherDays.length >= 3) {
    const a = moodOnStudyDays.reduce((s, v) => s + v, 0) / moodOnStudyDays.length;
    const b = moodOnOtherDays.reduce((s, v) => s + v, 0) / moodOnOtherDays.length;
    if (Math.abs(a - b) >= 0.4) {
      obs.push(a > b
        ? `Your logged mood tends to be higher on days with an hour or more of study.`
        : `Your logged mood tends to be lower on days with an hour or more of study — worth watching for burnout.`);
    }
  }

  // workout vs mood
  const moodOnWorkoutDays = days.filter(x => x.agg.workoutDone && x.agg.mood != null).map(x => x.agg.mood);
  const moodOnNoWorkoutDays = days.filter(x => !x.agg.workoutDone && x.agg.mood != null).map(x => x.agg.mood);
  if (moodOnWorkoutDays.length >= 3 && moodOnNoWorkoutDays.length >= 3) {
    const a = moodOnWorkoutDays.reduce((s, v) => s + v, 0) / moodOnWorkoutDays.length;
    const b = moodOnNoWorkoutDays.reduce((s, v) => s + v, 0) / moodOnNoWorkoutDays.length;
    if (a - b >= 0.4) obs.push(`Your logged mood is higher on days you work out.`);
  }

  return obs;
}

document.getElementById('range-toggle').addEventListener('click', (e) => {
  const btn = e.target.closest('.range-btn'); if (!btn) return;
  insightRange = Number(btn.dataset.range);
  document.querySelectorAll('.range-btn').forEach(b => b.classList.toggle('active', b === btn));
  renderInsights();
});

/* ===================== HABITS screen ===================== */
const HABIT_CATEGORIES = ['Discipline', 'Body', 'Mind', 'General'];
const HABIT_TYPES = [
  { value: 'boolean', label: 'Yes/No' },
  { value: 'count', label: 'Count' },
  { value: 'quantity', label: 'Quantity' },
];

function renderHabitsScreen() {
  const container = document.getElementById('habits-content');
  const grouped = {};
  HABIT_CATEGORIES.forEach(c => grouped[c] = []);
  state.habits.forEach(h => { (grouped[h.category] = grouped[h.category] || []).push(h); });

  container.innerHTML = `
    <div class="card">
      <h2 class="card-title">Add a habit</h2>
      <input type="text" id="new-habit-name" class="text-input" placeholder="e.g. Push-ups, Cold shower...">
      <div style="display:flex; gap:8px;">
        <select id="new-habit-category" class="select-input">
          ${HABIT_CATEGORIES.map(c => `<option value="${c}">${c}</option>`).join('')}
        </select>
        <select id="new-habit-freq" class="select-input">
          <option value="daily">Every day</option>
          <option value="3">3x / week</option>
          <option value="4">4x / week</option>
          <option value="5">5x / week</option>
        </select>
      </div>
      <button class="secondary-btn" id="add-habit-btn">Add habit</button>
    </div>
    ${HABIT_CATEGORIES.map(cat => grouped[cat].length ? `
      <div class="card">
        <h2 class="card-title">${cat}</h2>
        <div class="habit-checklist">
          ${grouped[cat].map(h => `
            <div class="habit-row">
              <span class="habit-name">${escapeHtml(h.name)}</span>
              <span class="habit-progress-text">${habitFreqLabel(h)}</span>
              <button class="icon-btn" data-id="${h.id}" aria-label="Delete ${escapeHtml(h.name)}" style="margin-left:8px;">✕</button>
            </div>
          `).join('')}
        </div>
      </div>
    ` : '').join('')}
  `;

  container.querySelectorAll('.icon-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.habits = state.habits.filter(h => h.id !== btn.dataset.id);
      saveState();
      renderHabitsScreen();
    });
  });

  document.getElementById('add-habit-btn').addEventListener('click', () => {
    const nameInput = document.getElementById('new-habit-name');
    const name = nameInput.value.trim();
    if (!name) return;
    const category = document.getElementById('new-habit-category').value;
    const freqVal = document.getElementById('new-habit-freq').value;
    const frequency = freqVal === 'daily' ? { type: 'daily' } : { type: 'times_per_week', times: Number(freqVal) };
    state.habits.push({ id: 'h_' + Date.now(), name, category, type: 'boolean', frequency });
    saveState();
    nameInput.value = '';
    renderHabitsScreen();
  });
}
function habitFreqLabel(h) {
  const f = h.frequency || { type: 'daily' };
  if (f.type === 'daily') return 'Daily';
  if (f.type === 'times_per_week') return `${f.times}x/week`;
  return '';
}

/* ===================== SETTINGS screen ===================== */
function renderSettings() {
  const s = state.settings;
  const container = document.getElementById('settings-content');
  container.innerHTML = `
    <div class="card">
      <h2 class="card-title">Appearance</h2>
      <div class="settings-row">
        <span>Theme</span>
        <div class="segmented small" id="theme-group" style="width:210px;">
          <button type="button" class="segment ${state.theme === 'system' ? 'selected' : ''}" data-value="system">System</button>
          <button type="button" class="segment ${state.theme === 'light' ? 'selected' : ''}" data-value="light">Light</button>
          <button type="button" class="segment ${state.theme === 'dark' ? 'selected' : ''}" data-value="dark">Dark</button>
        </div>
      </div>
      <p class="settings-note" style="margin-top:8px;">Dark Minimal is near-black with restrained accents. Light Clean is off-white with dark text. System follows your phone's setting.</p>
    </div>

    <div class="card">
      <h2 class="card-title">Study targets</h2>
      <div class="settings-input-row"><span>Minimum (min)</span><input type="number" class="text-input" id="set-study-min" value="${s.studyDailyMin}"></div>
      <div class="settings-input-row"><span>Target (min)</span><input type="number" class="text-input" id="set-study-target" value="${s.studyDailyTarget}"></div>
      <div class="settings-input-row"><span>Excellent (min)</span><input type="number" class="text-input" id="set-study-excellent" value="${s.studyDailyExcellent}"></div>
      <div class="settings-input-row"><span>Weekly target (min)</span><input type="number" class="text-input" id="set-study-weekly" value="${s.studyWeeklyTarget}"></div>
      <div class="settings-input-row"><span>🍅 Pomodoro work (min)</span><input type="number" class="text-input" id="set-pomodoro-work" value="${s.pomodoroWorkMin}"></div>
      <div class="settings-input-row"><span>🍅 Pomodoro break (min)</span><input type="number" class="text-input" id="set-pomodoro-break" value="${s.pomodoroBreakMin}"></div>
    </div>

    <div class="card">
      <h2 class="card-title">Body &amp; consistency targets</h2>
      <div class="settings-input-row"><span>Workout — times/week</span><input type="number" class="text-input" id="set-workout-weekly" value="${s.workoutWeeklyTarget}"></div>
      <div class="settings-input-row"><span>Meditation — times/week</span><input type="number" class="text-input" id="set-meditation-weekly" value="${s.meditationWeeklyTarget}"></div>
      <div class="settings-input-row"><span>Water target (L)</span><input type="number" step="0.5" class="text-input" id="set-water-target" value="${s.waterDailyTarget}"></div>
      <div class="settings-input-row"><span>Steps target</span><input type="number" class="text-input" id="set-steps-target" value="${s.stepsDailyTarget}"></div>
      <button class="secondary-btn" id="save-targets-btn">Save targets</button>
    </div>

    <div class="card">
      <h2 class="card-title">Recovery</h2>
      <p class="settings-note">Strict mode: a slip resets the recovery streak. Rest days are neutral. A slip never zeroes out the rest of your day's score.</p>
      <p class="field-label" style="margin-top:10px;">Custom triggers (comma-separated)</p>
      <input type="text" class="text-input" id="set-triggers" value="${escapeHtml(s.triggers.join(', '))}">
      <button class="secondary-btn" id="save-triggers-btn">Save triggers</button>
    </div>

    <div class="card">
      <h2 class="card-title">Study subjects</h2>
      <p class="field-label">Comma-separated</p>
      <input type="text" class="text-input" id="set-subjects" value="${escapeHtml(s.studySubjects.join(', '))}">
      <button class="secondary-btn" id="save-subjects-btn">Save subjects</button>
    </div>

    <div class="card">
      <h2 class="card-title">Reminders</h2>
      <p class="settings-note">Optional, on-device only reminders while the app is open. Steadfast never uses shame-based language — expect nudges like "Your study target is still open today," never "you failed."</p>
      <div class="settings-row"><span>Evening reflection prompt</span>
        <div class="segmented small" id="reflect-toggle" style="width:100px;">
          <button type="button" class="segment ${s.eveningReflection ? 'selected' : ''}" data-value="on">On</button>
          <button type="button" class="segment ${!s.eveningReflection ? 'selected' : ''}" data-value="off">Off</button>
        </div>
      </div>
    </div>

    <div class="card">
      <h2 class="card-title">Your data</h2>
      <p class="settings-note">Everything is stored privately on this device only. Nothing is sent anywhere.</p>
      <button class="secondary-btn" id="export-btn">Export data as JSON</button>
      <button class="danger-btn" id="clear-btn">Erase all data</button>
    </div>

    <div class="card">
      <h2 class="card-title">📵 App Blocker</h2>
      <p class="settings-note" id="blocker-status-note">Android app only — block distracting apps during a session.</p>
      <button class="secondary-btn" id="open-blocker-btn">Open App Blocker</button>
    </div>

    <div class="card">
      <h2 class="card-title">About</h2>
      <p class="settings-note">Steadfast v2.0 — event-based, installable, offline-first, private.</p>
    </div>
  `;

  container.querySelector('#theme-group').addEventListener('click', (e) => {
    const seg = e.target.closest('.segment'); if (!seg) return;
    state.theme = seg.dataset.value; saveState(); applyTheme(); renderSettings();
  });

  container.querySelector('#save-targets-btn').addEventListener('click', () => {
    s.studyDailyMin = Number(container.querySelector('#set-study-min').value) || s.studyDailyMin;
    s.studyDailyTarget = Number(container.querySelector('#set-study-target').value) || s.studyDailyTarget;
    s.studyDailyExcellent = Number(container.querySelector('#set-study-excellent').value) || s.studyDailyExcellent;
    s.studyWeeklyTarget = Number(container.querySelector('#set-study-weekly').value) || s.studyWeeklyTarget;
    s.pomodoroWorkMin = Number(container.querySelector('#set-pomodoro-work').value) || s.pomodoroWorkMin;
    s.pomodoroBreakMin = Number(container.querySelector('#set-pomodoro-break').value) || s.pomodoroBreakMin;
    s.workoutWeeklyTarget = Number(container.querySelector('#set-workout-weekly').value) || s.workoutWeeklyTarget;
    s.meditationWeeklyTarget = Number(container.querySelector('#set-meditation-weekly').value) || s.meditationWeeklyTarget;
    s.waterDailyTarget = Number(container.querySelector('#set-water-target').value) || s.waterDailyTarget;
    s.stepsDailyTarget = Number(container.querySelector('#set-steps-target').value) || s.stepsDailyTarget;
    saveStateNow();
    toast('Targets saved');
  });

  container.querySelector('#save-triggers-btn').addEventListener('click', () => {
    const list = container.querySelector('#set-triggers').value.split(',').map(t => t.trim()).filter(Boolean);
    if (list.length) { s.triggers = list; saveStateNow(); toast('Triggers saved'); }
  });
  container.querySelector('#save-subjects-btn').addEventListener('click', () => {
    const list = container.querySelector('#set-subjects').value.split(',').map(t => t.trim()).filter(Boolean);
    if (list.length) { s.studySubjects = list; saveStateNow(); toast('Subjects saved'); }
  });

  container.querySelector('#reflect-toggle').addEventListener('click', (e) => {
    const seg = e.target.closest('.segment'); if (!seg) return;
    s.eveningReflection = seg.dataset.value === 'on';
    saveStateNow(); renderSettings();
  });

  container.querySelector('#export-btn').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `steadfast-export-${todayKey()}.json`; a.click();
    URL.revokeObjectURL(url);
  });
  container.querySelector('#clear-btn').addEventListener('click', () => {
    if (!confirm('This will permanently erase all logs and habits from this device. Continue?')) return;
    state = freshState();
    saveStateNow();
    switchView('today');
  });
  container.querySelector('#open-blocker-btn').addEventListener('click', openAppBlockerModal);
  if (AppBlockerBridge.available) {
    AppBlockerBridge.getBlockingStatus().then(s => {
      const note = document.getElementById('blocker-status-note');
      if (note) note.textContent = s.active ? `Active — blocking ${s.blockedPackages.length} app${s.blockedPackages.length === 1 ? '' : 's'}.` : 'Not active.';
    });
  }
}

/* ===================== App Blocker (Android only) ===================== */
async function openAppBlockerModal() {
  if (!AppBlockerBridge.available) {
    openModal(`
      <h2 class="modal-title">📵 App Blocker</h2>
      <p class="modal-subtitle">This feature is only available in the Steadfast Android app.</p>
      <button class="modal-btn secondary" id="close-blocker-btn">Close</button>
    `, (root) => root.querySelector('#close-blocker-btn').addEventListener('click', closeModal));
    return;
  }
  const status = await AppBlockerBridge.getBlockingStatus();
  const enabled = await AppBlockerBridge.isAccessibilityEnabled();
  const apps = await AppBlockerBridge.getInstalledApps();
  const selected = new Set(status.blockedPackages || []);

  function render() {
    openModal(`
      <h2 class="modal-title">📵 App Blocker</h2>
      <p class="modal-subtitle">Blocks selected apps only while a blocking session is active.</p>
      ${!enabled
        ? `<p class="settings-note">Accessibility permission is required for blocking to work.</p>
           <button class="modal-btn secondary" id="open-accessibility-btn">Open Accessibility Settings</button>`
        : `<p class="settings-note">Accessibility: enabled ✓</p>`}
      <p class="field-label" style="margin-top:14px;">Apps to block</p>
      <div class="chip-row" id="app-list" style="max-height:240px;overflow-y:auto;">
        ${apps.map(a => `<button class="chip ${selected.has(a.packageName) ? 'selected' : ''}" data-pkg="${escapeHtml(a.packageName)}">${escapeHtml(a.appName)}</button>`).join('') || '<p class="empty-note">No apps found.</p>'}
      </div>
      ${status.active
        ? `<button class="modal-btn danger" id="stop-blocking-btn" style="margin-top:16px;">Stop Blocking</button>`
        : `<button class="modal-btn" id="start-blocking-btn" style="margin-top:16px;">Start Blocking (${selected.size})</button>`}
      <button class="modal-btn ghost" id="close-blocker-btn">Close</button>
    `, (root) => {
      const accBtn = root.querySelector('#open-accessibility-btn');
      if (accBtn) accBtn.addEventListener('click', () => AppBlockerBridge.openAccessibilitySettings());
      root.querySelector('#app-list').addEventListener('click', (e) => {
        const chip = e.target.closest('.chip'); if (!chip) return;
        const pkg = chip.dataset.pkg;
        if (selected.has(pkg)) selected.delete(pkg); else selected.add(pkg);
        chip.classList.toggle('selected');
        const startBtn = document.getElementById('start-blocking-btn');
        if (startBtn) startBtn.textContent = `Start Blocking (${selected.size})`;
      });
      const startBtn = root.querySelector('#start-blocking-btn');
      if (startBtn) startBtn.addEventListener('click', async () => {
        await AppBlockerBridge.setBlockedApps(Array.from(selected));
        await AppBlockerBridge.startBlocking();
        status.active = true;
        render();
        toast('Blocking started');
      });
      const stopBtn = root.querySelector('#stop-blocking-btn');
      if (stopBtn) stopBtn.addEventListener('click', async () => {
        await AppBlockerBridge.stopBlocking();
        status.active = false;
        render();
        toast('Blocking stopped');
      });
      root.querySelector('#close-blocker-btn').addEventListener('click', closeModal);
    });
  }
  render();
}
function resolveEffectiveTheme() {
  if (state.theme === 'light' || state.theme === 'dark') return state.theme;
  // 'system' (or unset) — follow the OS/browser preference
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) return 'light';
  return 'dark';
}
function applyTheme() {
  const effective = resolveEffectiveTheme();
  document.documentElement.setAttribute('data-theme', effective);
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) metaTheme.setAttribute('content', effective === 'light' ? '#F6F4EF' : '#14181A');
}

/* ===================== PWA install prompt ===================== */
let deferredInstallPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  document.getElementById('install-toast').classList.remove('hidden');
});
document.getElementById('install-btn').addEventListener('click', async () => {
  document.getElementById('install-toast').classList.add('hidden');
  if (deferredInstallPrompt) { deferredInstallPrompt.prompt(); await deferredInstallPrompt.userChoice; deferredInstallPrompt = null; }
});
document.getElementById('install-dismiss').addEventListener('click', () => {
  document.getElementById('install-toast').classList.add('hidden');
});

/* ===================== Service worker ===================== */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(err => console.warn('SW registration failed', err));
  });
  // Actions taken on the lock-screen/notification (Pause, Resume, Stop) are handled by the
  // service worker; if this page is still open (even backgrounded) it gets messaged directly.
  navigator.serviceWorker.addEventListener('message', (event) => {
    const msg = event.data || {};
    if (msg.type === 'study-pause') { pauseStudySession(); renderToday(); }
    else if (msg.type === 'study-resume') { resumeStudySession(); renderToday(); }
    else if (msg.type === 'study-stop') {
      const evt = stopStudySession(msg.subject || lastStudySubjectGuess(), null);
      renderToday();
      if (evt) toast(`Logged ${fmtMinutes(evt.durationMin)} (stopped from notification)`);
    } else if (msg.type === 'reconcile') {
      reconcileStudySessionFromBackground();
    }
  });
}
// Whenever the app returns to the foreground, reconcile against anything that happened
// in the service worker/notification while it was away — this is what keeps the timer and
// study history correct after locking the phone, switching apps, or the tab being discarded.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') reconcileStudySessionFromBackground();
});

/* ===================== Init ===================== */
applyTheme();
if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
    if (state.theme === 'system') applyTheme();
  });
}
switchView('today');
reconcileStudySessionFromBackground();
if (state.activeSession) syncSessionToIDB(); // keep IDB mirror fresh in case it was cleared

// keep Today's live timer button label in sync if a study session is active while idle on Today,
// and keep Focus Mode's big display in sync too. This is a *display* refresh only — actual
// elapsed time is always recomputed from timestamps, never accumulated by this interval.
setInterval(() => {
  checkPomodoroPhase();
  if (state.activeSession && !document.getElementById('view-today').classList.contains('hidden')) {
    const btn = document.getElementById('study-action-btn');
    if (btn) btn.textContent = state.activeSession.isPaused ? '⏸ Paused — tap to resume' : '⏱ Studying — tap to open';
  }
  if (focusModeOpen) updateFocusDisplay();
}, 1000);
